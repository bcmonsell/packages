#' Color name for display
#'
#' Generates color names for display on plot labels and subheaders
#'
#' @param this_color_code character string of color code to be used in plot
#' @return character string of color name closest to hexidecimal color input (if used) stripped of numbers
#' @examples
#' this_color_blind <- color_blind_palette()
#' this_color_blind_text <- array(NA, dim = 8)
#' for (i in 1:8) {
#'     this_color_blind_text[i] <- display_color(this_color_blind[i])
#' }
#' @export
display_color <- function(this_color_code) {
    # Author: Brian C. Monsell (OEUS) Version 1.2, 3/29/2021

    # check if color code starts with \code{'#'}
    if (substr(this_color_code, 1, 1) == "#") {
        this_color_code <- cnv_color_codes(this_color_code)
    }
    # return result after removing numbers from the end of the code
    return(gsub('[0-9]+', '', this_color_code))
}