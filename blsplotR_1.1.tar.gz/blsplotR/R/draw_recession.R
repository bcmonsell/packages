#' Draw NBER recessions
#'
#' Draws shaded areas in plots corresponding to NBER recessions
#'
#' @param this_col_recess Character string; color used for shading recession periods. Default is \code{'lightgrey'}.
#' @param this_density the density of shading lines, in lines per inch. The default value is 50. A zero value of density means no shading lines whereas negative values (and NA) suppress shading (and so allow color filling).
#' @param this_border Integer scalar; thickness of border around region. Default is \code{NA}, meaning the border is not generated.
#' @param this_add_recess_start numeric scalar; Starting date for an additional recession period at the end of the series. Default is not to add recession dates.
#' @param this_sub_recess Logical scalar; indicates if x-axis label for recession is produced for this plot. Default is x-axis label is produced
#' @param this_sub_line Integer scalar; position of subtitle of plot.  Default is \code{3}.
#' @param this_sub_cex Numeric scalar; scaling for subtitle of plot. Default is \code{0.75}.
#' @return Shades recession dates in plots 
#' @examples
#' m_air <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', x11='')
#' plot_table(m_air, 'a1', 'AirPassengers', do_grid = TRUE, draw_recess = FALSE,
#'           use_ratio = FALSE, add_sub_title = TRUE, this_col = 'green')
#' start_pandemic_recession <- 2020 + 1/12 # start of pandemic recession February 2020
#' draw_recession(this_col_recess = 'lightblue', this_border = 1, 
#'                this_add_recess_start = start_pandemic_recession,
#'                this_sub_line = 1.5, this_sub_cex = 0.9)
#' mtext('NBER Recessions in Blue',1,3,cex=0.75)
#' @import graphics
#' @export
draw_recession <- function(this_col_recess = NULL, this_density = 50, this_border = NA,
                           this_add_recess_start = NULL, this_sub_recess = TRUE, this_sub_line = 3, 
                           this_sub_cex = 0.75) {
    # Author: Brian C. Monsell (OEUS) Version 3.3, 03/25/2021
    
    # set color of recession region, if not specified
    if (is.null(this_col_recess)) {
        this_col_recess <- "lightgrey"
    }

    # get min and max of x and y axis from par
    plot_lim <- par("usr")

    # use get_recession_dates to get beginning and ending dates for recessions
    this_recession <- get_recession_dates(start_recess = plot_lim[1], end_recess = plot_lim[2],
                                          add_recess_start = this_add_recess_start)

    # if no recession periods found, return
    if (nrow(this_recession) == 0) {
        return()
    }

    # process each date
    for (i in 1:nrow(this_recession)) {
        # use rect to draw shaded regions for the dates of the recession from the top and bottom of the y
        # axis.
        rect(this_recession[i, 1], plot_lim[3], this_recession[i, 2], plot_lim[4], col = this_col_recess,
            density = this_density, border = this_border)
    }
   
    if (this_sub_recess) { 
        mtext(tools::toTitleCase(paste0("NBER Recessions in ", display_color(this_col_recess))), 
              1, this_sub_line, cex = this_sub_cex) 
    }
}
