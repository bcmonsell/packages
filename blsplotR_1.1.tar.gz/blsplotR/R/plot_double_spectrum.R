#' Generate double spectrum plot of the original and seasonally adjusted series.
#'
#' Generate plot of spectrum of original series and seasonally adjusted series on same axis.
#'
#' @param m_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @param xaxis_bls Logical scalar; indicates if x-axis of spectral plot will be frequency by month rather than the actual frequencies. Default sets x-axis to frequency by month.
#' @param main_title Character string; main title of plot.  Default is  \code{'AR Spectrum'}.
#' @param series_name Character scalar; name of the time series used in m.
#' @param this_col Character array of length 6; color used in specturm plots, in the order of spectrum of ori, spectrum of SA, line for seasonal frequency, line for TD frequency, star for visually significant seasonal frequency, star for visually significant TD frequency. Default is \code{c('blue', 'green', 'grey', 'brown', 'red', 'orange')}.
#' @return Generate plot of spectrum of original series and seasonally adjusted series on same axis.
#' @examples
#' m_air <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', x11='')
#' plot_double_spectrum(m_air, series_name = 'AirPassengers',
#'          this_col = c('blue', 'green', 'darkblue', 'darkgreen', 'red', 'orange'))
#' @import graphics
#' @export
plot_double_spectrum <- function(m_seas = NULL, xaxis_bls = TRUE, main_title = "AR Spectrum", series_name = NULL,
    this_col = c("blue", "green", "grey", "brown", "red", "orange")) {
    # Author: Brian C. Monsell (OEUS) Version 2.9, 3/25/2021

    # check if a value is specified for \code{m_seas}
    if (is.null(m_seas)) {
        stop("must specify a seas object")
    }
    
    # extract spectrum of seasonally adjusted series for X-11
    sp1 <- seasonal::series(m_seas, "sp1")
    # if not available, try to extract spectrum of seasonally adjusted series for SEATS
    if (is.null(sp1)) {
        sp1 <- seasonal::series(m_seas, "s1s")
        # if not available, print error message and stop
        if (is.null(sp1)) {
            stop("unable to extract spectrum of seasonally adjusted series")
        }
    }
    # extract spectrum of original series
    sp0 <- seasonal::series(m_seas, "sp0")

    # initialize seasonal and trading day frequencies
    f_seas <- 1:5/12
    f_td <- c(0.3482, 0.432)

    # if series name specified, add to title
    if (!is.null(series_name)) {
        main_title <- paste(main_title, " for ", series_name)
    }

    if (xaxis_bls) {
        # plot original spectrum without x-axis
        plot(sp0, type = "l", ylim = range(sp0[, 2], sp1[, 2]), xaxt = "n", ylab = " ", xlab = "Period in Months",
            col = this_col[1])
        # generate alternate x-axis
        axis(1, at = c(0, f_seas, 0.5), labels = c(expression(infinity), 1/f_seas, 2))
    } else {
        # plot original spectrum
        plot(sp0, type = "l", ylim = range(sp0[, 2], sp1[, 2]), col = this_col[1], ylab = " ")
    }

    # plot SA spectrum
    lines(sp1, col = this_col[2])

    # plot titile and subtitles
    mtext(main_title, 3, 2.75, cex = 1.25)
    mtext(tools::toTitleCase(paste("Ori Spec - ", display_color(this_col[1]),
          ", SA Spec - ", display_color(this_col[2]))), 
          3, 1.75, cex = 0.8)
    mtext("Dotted Line - Median, Star - Visual Peak", 3, 0.75, cex = 0.8)

    # draw lines for spectrum medians
    abline(h = as.numeric(seasonal::udg(m_seas, "spcori.median")), lty = 2, col = this_col[1])
    abline(h = as.numeric(seasonal::udg(m_seas, "spcsa.median")), lty = 2, col = this_col[2])

    # draw lines for seasonal and TD frequencies
    abline(v = f_seas, lty = 3, col = this_col[3])
    abline(v = f_td, lty = 3, col = this_col[4])

    # get min and max of x and y axis from par
    plotLim <- par("usr")

    # put 'TD' near trading day frequencies
    ypos <- plotLim[4] - (plotLim[4] - plotLim[3])/30
    for (i in 1:length(f_td)) {
        text(f_td[i], ypos, "TD", col = this_col[4], cex = 0.75)
    }

    # determine if there are visually significant peaks in the spectrum of the original series.
    vp_ori_seas <- visual_sig_peaks(m_seas, "ori")
    vp_ori_td <- visual_sig_peaks(m_seas, "ori", "td")

    # Add stars for visually significant seasonal peaks.
    if (vp_ori_seas[1] > 0) {
        for (i in 1:length(vp_ori_seas)) {
            indx <- vp_ori_seas[i] + 1
            text(sp0[indx, 1], sp0[indx, 2], "*", col = this_col[5], cex = 1.2)
        }
    }

    # Add stars for visually significant trading day peaks.
    if (vp_ori_td[1] > 0) {
        for (i in 1:length(vp_ori_td)) {
            indx <- vp_ori_td[i] + 1
            text(sp0[indx, 1], sp0[indx, 2], "*", col = this_col[6], cex = 1.2)
        }
    }

    # determine if there are visually significant peaks in the spectrum of the SA series.
    vp_sa_seas <- visual_sig_peaks(m_seas, "sa")
    vp_sa_td <- visual_sig_peaks(m_seas, "sa", "td")

    # Add stars for visually significant seasonal peaks.
    if (vp_sa_seas[1] > 0) {
        for (i in 1:length(vp_sa_seas)) {
            indx <- vp_sa_seas[i] + 1
            text(sp1[indx, 1], sp1[indx, 2], "*", col = this_col[5], cex = 1.2)
        }
    }

    # Add stars for visually significant trading day peaks.
    if (vp_sa_td[1] > 0) {
        for (i in 1:length(vp_sa_td)) {
            indx <- vp_sa_td[i] + 1
            text(sp1[indx, 1], sp1[indx, 2], "*", col = this_col[6], cex = 1.2)
        }
    }

}
