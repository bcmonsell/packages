#' Plot time series matrix
#'
#' Generate plot of a matrix of user-specified time series.
#'
#' @param this_matrix Numeric matrix; columns of time series object to be plotted.
#' @param main_title Character string; main title of plot.  Default is column name.
#' @param main_title_line Integer scalar; position of main title of plot.  Default is \code{2.75}.
#' @param main_title_cex Numeric scalar; scaling for main title of plot. Default is \code{1.25}.
#' @param y_label Character string; y-axis label for plot, if specified.
#' @param start_plot Integer vector of length 2; Starting date for plot. Default is starting date for the time series.
#' @param do_grid Logical scalar; indicates if certain plots will have grid lines. Default is no grid lines.
#' @param draw_recess Logical scalar; indicates if certain plots will have shaded areas for NBER recession dates. Default is no recession shading.
#' @param recess_start numeric matrix; Rows of dates for additional recession starting and ending dates. Default is not to add recession dates.
#' @param recess_col Character string; color used for shading of recession region. Default is \code{'lightgrey'}.
#' @param recess_sub Logical scalar; indicates if x-axis label for recession is produced for this plot. Default is x-axis label is produced
#' @param this_col Character array of length 6; color used for series in the order specified by the user. Default is \code{c('grey', 'blue', 'green', 'brown', 'red', 'yellow')}.
#' @param this_line_type Integer vector; indicates line type of each plot produced. Default is 1:6
#' @param add_legend Logical scalar; indicates if legend is produced for this plot. Default is legend not produced
#' @param this_legend_position Character string; indicates position of legend. Default is \code{'topleft'}.
#' @param this_legend_title Character string; indicates title of legend. Default is \code{'Series'}.
#' @param this_legend_inset Integer scalar; indicates inset for legend. Default is \code{0}.
#' @param this_legend_entry Character array; entries for the lengend. Default is \code{'Srs1'}.
#' @param this_legend_cex Numeric scalar; scaling for legend. Default is \code{0.8}.
#' @return Generate plot of user-specified series. If matrix not specified, print out error message and return NULL.
#' @examples
#' BP_Region_Matrix <-
#'    cbind(xt_data_list$mw1u, xt_data_list$ne1u, xt_data_list$so1u, xt_data_list$we1u)
#' plot_matrix(BP_Region_Matrix, y_label = 'Building Permits', do_grid = TRUE,
#'             draw_recess = TRUE, this_col = c("grey", "blue", "green", "brown"))
#' @import graphics
#' @import stats
#' @export
plot_matrix <- function(this_matrix = NULL, main_title = NULL, main_title_line = 2.75,
    main_title_cex = 1.25, y_label = NULL, start_plot = NULL, do_grid = FALSE,
    draw_recess = FALSE, recess_start = NULL, recess_col = NULL, recess_sub = TRUE,
    this_col = c("grey", "blue", "green", "brown", "red", "yellow"),
    this_line_type = rep(1, 6), add_legend = FALSE, this_legend_position = "topleft", this_legend_title = "Series",
    this_legend_inset = 0, this_legend_entry = paste("srs", 1:6, sep = ""), this_legend_cex = 0.8) {
    # Author: Brian C. Monsell (OEUS) Version 1.11, 4/2/2022

    if (is.null(this_matrix)) {
        stop("Argument this_matrix must be specified.")
    }

    num_series <- ncol(this_matrix)

    if (length(this_line_type) < num_series) {
        warning("Number of line types specified less than number of series.")
        warning("Remaining elements set to be the first entry.")
        this_line_type <- sautilities::update_vector(this_line_type, num_series)
    }

    if (length(this_col) < num_series) {
        warning("Number of line colors specified less than number of series.")
        warning("Remaining elements set to be the first entry.")
        this_col <- sautilities::update_vector(this_col, num_series)
    }

    if (!is.null(start_plot)) {
        y_range <- range(window(this_matrix, start = start_plot))
    } else {
        y_range <- range(this_matrix)
    }

    for (i in 1:num_series) {

        this_series <- this_matrix[, i]

        # If start_plot specified, shorten series
        if (!is.null(start_plot)) {
            this_series <- window(this_series, start = start_plot)
        }

        if (i == 1) {
            # Generate plot with title.
            plot(this_series, xlab = " ", ylab = " ", type = "n", ylim = y_range)
            mtext(main_title, 3, 2.75, cex = 1.25)
            # add y-axis label, if specified.
            if (!is.null(y_label)) {
                mtext(y_label, main_title_line, main_title_cex)
            }
        }
        lines(this_series, col = this_col[i], lty = this_line_type[i])
    }

    # add grid.
    if (do_grid) {
        grid()
    }

    # add shaded regions for recessions.
    if (draw_recess) {
        draw_recession(recess_col, this_add_recess_start = recess_start,
                       this_sub_recess = recess_sub)
    }

    # add legend to plot
    if (add_legend) {
        legend(this_legend_position, this_legend_entry, title = this_legend_title, inset = this_legend_inset,
            cex = this_legend_cex, col = this_col[1:num_series], lty = this_line_type[1:num_series])
    }

}
