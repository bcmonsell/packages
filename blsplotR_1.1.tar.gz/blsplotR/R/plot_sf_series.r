#' Seasonal factor (and the SI-ratios) plot grouped by month/quarter
#'
#' Generates a special plot of the seasonal factors (and the SI-ratios) grouped by month/quarter
#'
#' @param this_sf array of seasonal factors stored as a time series
#' @param y_limit Numeric vector of length 2; Range of values you wish the plot to be plotted over. Default is range of the seasonal factors.
#' @param this_trans Logical scalar; indicates if the adjustment was done with a log transform. Default is TRUE.
#' @param main_title Character string; main title of plot.  Default is  \code{'Seasonal Sub-Plots'}.
#' @param this_xlab Character string; label for x-axis of plot.  Default is a blank x-axis.
#' @param this_col Character array of length 2; color used for seasonal factors, SI-ratios, and seasonal mean. Default is \code{c("darkgreen", "darkblue", "darkgrey")}.
#' @param update_plot Logical scalar; indicates if this is being added to an existing plot. Default is FALSE.
#' @param add_mean_line Logical scalar; indicates if seasonal factor plots will include lines for seasonal means. Default includes lines for seasonal means.
#' @param add_legend Logical scalar; indicates if legend is produced for this plot. Default is legend not produced
#' @param this_legend_position Character string; indicates position of legend. Default is \code{'topleft'}.
#' @param this_legend_text Array of character strings; indicates text for each seasonal factor in plot. Default is \code{c("SF", "SF Mean")}.
#' @param this_legend_title Character string; indicates title of legend. Default is \code{'Series'}.
#' @param this_legend_inset Integer scalar; indicates inset for legend. Default is \code{0}.
#' @param this_legend_color Array of character strings; indicates color for each seasonal factor in plot. Default is same as \code{this_col}
#' @param this_legend_cex Numeric scalar; scaling for legend. Default is \code{0.8}.
#' @return Generates a special plot of the seasonal factors (and the SI-ratios) grouped by month/quarter
#' @examples
#' air_seas       <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', x11='')
#' air_seats_seas <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)')
#' air_sf       <- seasonal::series(air_seas, "d10")
#' air_seats_sf <- seasonal::series(air_seats_seas, "s10")
#' sf_range <- range(air_sf, air_seats_sf)
#' plot_sf_series(air_sf, y_limit = sf_range, add_mean_line = FALSE,
#'                main_title = 'Air Passengers Seasonal Sub-Plots',
#'                this_col = 'darkgreen', add_legend = TRUE,
#'                this_legend_text = c("sf(x11)", "sf(seats)"),
#'                this_legend_color = c('darkgreen', 'darkblue'))
#' plot_sf_series(air_seats_sf, y_limit = sf_range, add_mean_line = FALSE,
#'                this_col = 'darkblue', update_plot = TRUE,  
#'                add_legend = FALSE)
#' @import graphics
#' @import stats
#' @export
plot_sf_series <- function(this_sf = NULL, y_limit = NULL, this_trans = TRUE, main_title = "Seasonal Sub-Plots",
    this_xlab = " ", this_col = c("darkgreen", "darkgrey"), update_plot = FALSE, add_mean_line = TRUE,
    add_legend = FALSE, this_legend_position = "topleft", this_legend_text = c("SF", "SF Mean"),
    this_legend_title = "SF Plot", this_legend_inset = 0, this_legend_color = this_col,
    this_legend_cex = 0.8) {
    # Author: Brian C. Monsell (OEUS) Version 1.8, 11/12/2021

    # check if a value is specified for \code{this_sf}
    if (is.null(this_sf)) {
        stop("must specify seasonal factors")
    }

    # Extract cycle and frequency
    sf_period <- cycle(this_sf)
    freq <- frequency(this_sf)

    # Set up range of x and y axis.
    if (is.null(y_limit)) {
        y_limit <- range(this_sf)
    }
    x_limit <- seq(0, freq + 1)

    # Set value of factor mean.
    if (this_trans) {
        h_bar <- 1
    } else {
        h_bar <- 0
    }

    if (!update_plot) {
        # create the plotting frame, with custom x-axis and create reference line for factor mean.
        plot(x_limit, seq(y_limit[1], y_limit[2], length.out = length(x_limit)), main = main_title, type = "n",
            ylim = y_limit, xlab = this_xlab, ylab = " ", xaxt = "n")

        # Generate monthly labels
        if (freq == 12) {
            this_label <-
               c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
        } else {
            # Generate quarterly labels
            if (freq == 4) {
                this_label <- paste0("q", 1:4)
            } else {
                this_label <- paste0("p", 1:freq)
            }
        }
        axis(1, at = 1:freq, labels = this_label)
        if (add_mean_line) {
            abline(h = h_bar, col = this_col[3], lty = 2)
        }
    }

    # create vector for factor mean.
    this_mu <- array(h_bar, freq)

    # loop through each month or quarter.
    for (i in 1:freq) {

        # produce limits for period plot.
        s1 <- (i - 1) + 0.6
        s2 <- i + 0.4

        # save seasonal factors for period i, and generate number of factors.
        sf <- this_sf[sf_period == i]
        number_sf <- length(sf)

        # Generate X values for period i, mean of SF for period i
        this_period_x <- seq(s1, s2, length.out = number_sf)
        this_mu[i] <- mean(sf)

        if (add_mean_line) {
            # Generate line for mean of SF for period i
            segments(s1, this_mu[i], s2, this_mu[i], col = this_col[3])
        }

        # Plot SF for period i
        lines(this_period_x, sf, col = this_col[1])

    }

    # add legend to plot
    
    if (!update_plot) {
        if (add_legend) {
            legend(this_legend_position, this_legend_text, title = this_legend_title, inset = this_legend_inset,
                   cex = this_legend_cex, col = this_legend_color, lty = rep(1,2))
        }
    }


}
