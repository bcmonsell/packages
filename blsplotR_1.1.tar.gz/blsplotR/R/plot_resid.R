#' Residual plot
#'
#' Generates a plot of the regARIMA residuals with diagnostic information
#'
#' @param m_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @param main_title Character string; main title of plot.  Default is  \code{'ARIMA Residuals'}.
#' @param series_name Character scalar; name of the time series used in m.
#' @param do_grid Logical scalar; indicates if certain plots will have grid lines. Default is grid lines plotted.
#' @param draw_recess Logical scalar; indicates if certain plots will have shaded areas for NBER recession dates. Default is recession shading plotted.
#' @param recess_start numeric matrix; Rows of dates for additional recession starting and ending dates. Default is not to add recession dates.
#' @param recess_col Character string; color used for shading of recession region. Default is \code{'lightgrey'}.
#' @param recess_sub Logical scalar; indicates if x-axis label for recession is produced for this plot. Default is x-axis label is produced
#' @param use_ratio Logical scalar; indicates if plots of seasonal factors, irregular, and residuals are done as ratio plots. Default has these plots as time series line plots.
#' @param this_col Character string; color used for residuals. Default is \code{'green'}.
#' @return Generates a plot of the regARIMA residuals with diagnostic information in the sub-headers.
#' @examples
#' m_air <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)')
#' plot_resid(m_air, main_title = 'ARIMA Residuals for Airline Passengers', use_ratio = TRUE,
#'            this_col='darkblue')
#' @import graphics
#' @import utils
#' @export
plot_resid <- function(m_seas = NULL, main_title = "ARIMA Residuals", series_name = NULL, do_grid = TRUE,
    draw_recess = TRUE, recess_start = NULL, recess_col = NULL, recess_sub = TRUE, 
    use_ratio = FALSE, this_col = "green") {
    # Author: Brian C. Monsell (OEUS) Version 4.3, 4/20/2021

    # check if a value is specified for \code{m_seas}
    if (is.null(m_seas)) {
        stop("must specify a seas object")
    }
    
    # Extract regARIMA residuals
    resid <- seasonal::series(m_seas, "rsd")

    # Set plot margins
    this_log <- capture.output({
       old_par <- dput(par(no.readonly=TRUE))
    })
    par(mar = c(5, 3, 5, 1))

    # Generate main plot title
    if (!is.null(series_name)) {
        main_title <- paste(main_title, " for ", series_name)
    }

    # Generate ratio plot of residuals
    if (use_ratio) {
        plot_ratio(resid, ratio_color = this_col, ratio_mean = 0)
    } else {
        # Generate line plot of residuals
        plot(resid, ylab = " ", xlab = " ", type = "n")
        lines(resid, col = this_col)
    }

    # Generate zero line
    abline(h = 0)

    # Generate title
    mtext(main_title, 3, 3.25, cex = 1.25)

    # Generate grid
    if (do_grid) {
        grid()
    }

    # Generate recession region shading
    if (draw_recess) {
        draw_recession(recess_col, this_add_recess_start = recess_start, 
                       this_sub_recess = recess_sub)
    }

    # get residual diagnostics
    thisA <- tryCatch(seasonal::udg(m_seas, "a"), error = function(e) {
        print("Geary''s a not found")
        NULL
    })

    thisKurt <- tryCatch(seasonal::udg(m_seas, "kurtosis"), error = function(e) {
        print("kurtosis not found")
        NULL
    })

    thisSkew <- tryCatch(seasonal::udg(m_seas, "skewness"), error = function(e) {
        print("skewness not found")
        NULL
    })

    # generate subheaders for diagnostics
    sub1 <- NULL
    sub2 <- NULL
    sub3 <- NULL

    if (!is.null(thisA)) {
        if (length(thisA) > 1) {
            sub1 <- paste("Geary's a = ", sprintf("%4.1f", as.numeric(thisA[1])), " (", thisA[2],
                ")", sep = "")
        } else {
            sub1 <- paste("Geary's a = ", sprintf("%4.1f", thisA), sep = "")
        }
    }

    if (!is.null(thisKurt)) {
        if (length(thisKurt) > 1) {
            sub2 <- paste("Excess Kurtosis = ", sprintf("%4.1f", as.numeric(thisKurt[1])), " (", thisKurt[2],
                ")", sep = "")
        } else {
            sub2 <- paste("Excess Kurtosis = ", sprintf("%4.1f", thisKurt), sep = "")
        }
    }

    if (!is.null(thisSkew)) {
        if (length(thisSkew) > 1) {
            sub3 <- paste("Skewness = ", sprintf("%4.1f", as.numeric(thisSkew[1])), " (", thisSkew[2],
                ")", sep = "")
        } else {
            sub3 <- paste("Skewness = ", sprintf("%4.1f", thisSkew), sep = "")
        }
    }

    if (!is.null(sub1)) {
        mtext(sub1, 3, 2, cex = 0.75)
    }
    if (!is.null(sub2)) {
        if (!is.null(sub3)) {
            mtext(paste(sub2, ", ", sub3, sep = ""), 3, 1, cex = 0.75)
        } else {
            mtext(sub2, 3, 3, cex = 0.75)
        }
    } else {
        if (!is.null(sub3)) {
            mtext(sub3, 3, 1, cex = 0.75)
        }
    }

    # restore graphics parameters
    par(old_par)

}
