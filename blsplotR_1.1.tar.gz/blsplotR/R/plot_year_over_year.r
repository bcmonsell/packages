#' Year over year plot of individual series.
#'
#' Generate plot of user-specified series with each year as a separate line.
#'
#' @param this_series Numeric vector; time series object to be plotted.
#' @param main_title Character string; main title of plot.  Default is no title.
#' @param this_col Character array; color used for series in the order specified by the user.
#'        This array should be as long as the number of years plotted.
#'        If only one color is specified, \code{colortools::wheel(this_col)} is used to construct
#'        an array with enough colors.
#'        Default is \code{rainbow(ny)}, where \code{ny} is the number of years plotted.
#' @param start_plot Integer vector of length 2; Starting date for plot. Default is starting date for the time series.
#' @param this_legend Logical scalar; indicates if a legend is produced for the plot. Default is TRUE.
#' @param this_legend_cex Numeric scalar; scaling for legend. Default is \code{0.75}.
#' @param this_right_mar Numeric scalar; value associated with the margin of the right y-axis specified in the \code{mar} entry of the graphics parameters (\code{par}). 
#'        Default is \code{5.6}.
#' @param this_legend_inset Numeric scalar; value associated with the inset of the right legend.
#'        Default is \code{-0.1}.
#' @return Generate year over year plot of user-specified series. If series not specified, print out error message and return NULL.
#' @examples
#' plot_year_over_year(AirPassengers, "Airline Passenger Series (1949 - 1960)")
#' @import graphics
#' @import stats
#' @import utils
#' @export
plot_year_over_year <- function(this_series = NULL, main_title = NULL, this_col = NULL,
                                start_plot = NULL, this_legend = TRUE, this_legend_cex = 0.75,
                                this_right_mar = 5.6, this_legend_inset = -0.1) {
    # Author: Brian C. Monsell (OEUS) Version 2.11, 5/3/2021

   if (is.null(this_series)) {
       stop("Argument this_series must be specified.")
   }

   # get time series information
   if (is.null(start_plot)) {
       this_start <- start(this_series)
   } else {
       this_start <- start_plot
   }
   this_freq <- frequency(this_series)
   this_end   <- end(this_series)

   # set first and last year of plot, number of years
   this_first_year <- this_start[1]
   this_last_year  <- this_end[1]
   if (this_end[2] == 1) {
       this_last_year <- this_last_year - 1
   }

   n_years <- this_last_year - this_first_year + 1

   # set colors used in plots
   if (is.null(this_col)) {
       this_col <- rainbow(n_years)
   } else {
       if (length(this_col) == 1) {
           this_col <- wheel_invisible(this_col, n_colors = n_years)
       } else {
           if (length(this_col) < n_years) {
               stop(paste0("Specify ", n_years, " colors in argument this_col."))
           }
       }
   }
   this_range <- range(this_series)

   # plot first segment
   this_segment <- window(this_series, start = this_start,
                          end = c(this_first_year+1, 1))
   this_x <- seq(this_start[2], this_freq+1)

   this_x_lab <- " "
   this_axis_names <- NULL
   if (this_freq == 12) { 
       this_x_lab <- "Months"
       this_axis_names <- month.abb[c(1:12,1)]
   }
   if (this_freq == 4)  { 
       this_x_lab <- "Quarters" 
   }

   if (this_legend) {
       this_log <- capture.output({
           old_par <- dput(par(no.readonly=TRUE))
       })
       par(mar=c(5.1, 4.1, 4.1, this_right_mar), xpd=TRUE)
       this_years <- seq(this_first_year, this_last_year)
   }

   if (is.null(main_title)) {
       plot(this_x, this_segment, ylim = this_range, xaxt = "n",
            col = this_col[1], xlim = c(1, this_freq+1), type = "l",
            xlab = this_x_lab, ylab = " ")
   } else {
       plot(this_x, this_segment, ylim = this_range, xaxt ="n",
            col = this_col[1], xlim = c(1, this_freq+1), type = "l",
            xlab = this_x_lab, ylab = " ", main = main_title)
   }

   # plot final segment
   this_segment <- window(this_series, start = c(this_last_year, 1),
                          end = this_end)

   this_x <- seq(1, this_end[2])
   lines(this_x, this_segment, col = this_col[n_years])

   # plot rest of years
   this_seq <- seq(this_first_year + 1, this_last_year - 1)
   this_x <- seq(1, this_freq+1)

   this_i <- 2
   for (y in this_seq) {
        this_segment <- window(this_series, start = c(y,1), end = c(y+1, 1))
        lines(this_x, this_segment, col = this_col[this_i])
        this_i <- this_i + 1
   }

   # construct x axis
   if (is.null(this_axis_names)) {
       axis(1, at = this_x, labels=this_x)
   } else {
       axis(1, at = this_x, labels=this_axis_names)
   }

   # construct legend, if specified
   if (this_legend) {
       legend("topright", inset = c(this_legend_inset, 0), legend = this_years, col = this_col,
              title = "Years", cex = this_legend_cex, lty = rep(1, n_years))
       par(old_par)
   }


}
