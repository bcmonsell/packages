#' Generate cumulative periodogram of the regARIMA residuals
#'
#' Generates a plot of the cumulative periodogram of the regARIMA residuals
#'
#' @param m_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @param main_title Character string; main title of plot.  Default is  \code{'Cumulative periodogram'}.
#' @return Generates a plot of the Cumulative periodogram of the regARIMA residuals. Diagnostic information is included in subheaders.
#' @examples
#' m_air <- seasonal::seas(AirPassengers, transform.function= 'log', arima.model = '(0 1 1)(0 1 1)')
#' plot_cpgram_resid(m_air, main_title = 'Cumulative periodogram for Airline Passenger Residuals')
#' @import graphics
#' @import stats
#' @export
plot_cpgram_resid <- function(m_seas = NULL, main_title = "Cumulative periodogram") {
    # Author: Brian C. Monsell (OEUS) Version 2.4, 3/25/2021

    # check if a value is specified for \code{m_seas}
    if (is.null(m_seas)) {
        stop("must specify a seas object")
    }
    
    resid <- seasonal::series(m_seas, "rsd")
    cpgram(resid, main = main_title)
    m_acf <- seasonal::series(m_seas, "acf")
    freq <- seasonal::udg(m_seas, "freq")
    if (nrow(m_acf) < 2 * freq) {
        sub_header <- paste("LB", freq, "=", format(m_acf[freq, 3], digits = 2, nsmall = 1), ", PV", 
            freq, "=", format(m_acf[freq, 5], digits = 2, nsmall = 2), sep = "")
    } else {
        f2 <- freq * 2
        sub_header <- paste("LB", freq, "=", format(m_acf[freq, 3], digits = 2, nsmall = 1), ", PV", 
            freq, "=", format(m_acf[freq, 5], digits = 2, nsmall = 2), ", LB", f2, "=", format(m_acf[f2, 
                3], digits = 2, nsmall = 1), ", PV", f2, "=", format(m_acf[f2, 5], digits = 2, nsmall = 2), 
            sep = "")
    }
    mtext(sub_header, 3, 0.5, cex = 0.75)
}
