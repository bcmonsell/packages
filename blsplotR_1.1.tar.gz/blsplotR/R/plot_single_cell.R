#' Single time series plot.
#'
#' Generates a single plot of a time series, seasonal adjustment of the time series, and trend component. Plotting the trend is optional. 
#' The series name is used for the title.
#'
#' @param this_series Original time series
#' @param this_sadj Seasonal adjustment of \code{this_series}.
#' @param this_trend Trend component estimated from \code{this_series}. Default is to not print the trend component.
#' @param this_name Name of the original series. If specified, this is used as the title of the plot. Default is to generate the title based on what components are plotted.
#' @param col_vector Character vector of length 3; colors used for the lines in the plot. First color is for the oringial series, second is for the SA series, third is for the trend. Default is \code{col_vector=c('grey','blue','darkgreen')}.
#' @return Produces plot of single plot of a time series, seasonal adjustment of the time series, and trend component. No values are returned.
#' @examples
#' m_air <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', x11='')
#' plot_single_cell(AirPassengers,seasonal::final(m_air),seasonal::trend(m_air), 'Air Passengers')
#' @import graphics
#' @export
plot_single_cell <- function(this_series = NULL, this_sadj = NULL, this_trend = NULL, this_name = NULL, 
    col_vector = c("grey", "blue", "darkgreen")) {
    # Author: Brian C. Monsell (OEUS) Version 1.7, 3/25/2021
    
    if (is.null(this_series)) {
        stop("Argument this_series must be specified.")
    }

    if (is.null(this_sadj)) {
        stop("Argument this_sadj must be specified.")
    }

    # Set range of Y axis to be plotted
    if (is.null(this_trend)) {
        y_limit <- range(this_series, this_sadj)
    } else {
        y_limit <- range(this_series, this_sadj, this_trend)
    }
    
    # Generate frame of plot, then add lines for series as necessary
    plot(this_series, type = "n", xlab = " ", ylim = y_limit)
    lines(this_series, col = col_vector[1])
    lines(this_sadj, col = col_vector[2])
    if (!is.null(this_trend)) {
        lines(this_trend, col = col_vector[3])
    }
    
    # Add title to plot
    if (is.null(this_name)) {
        this_title <- "Plot of Original Series, SA"
        if (!is.null(this_trend)) {
            this_title <- paste(this_title, ", Trend", sep = "")
        }
        mtext(this_title, 3, 1)
    } else {
        mtext(this_name, 3, 1)
    }
}
