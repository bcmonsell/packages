#' Ratio plot
#'
#' Generates a high-definition plot around a reference line other than zero.
#'
#' @param ratio_series Time series of ratios/factors for which you want to generate a high definition plot
#' @param ratio_range Range of values you wish the plot to be plotted over. Default is range of the series.
#' @param main_title Title for the plot. Default is character string \code{'Ratio Plot'}.
#' @param main_title_line Integer scalar; position of main title of plot.  Default is \code{2.75}.
#' @param main_title_cex Numeric scalar; scaling for main title of plot. Default is \code{1.25}.
#' @param ratio_mean Assumed mean value for the ratio.  Default is \code{1.0}
#' @param ratio_color Color used for lines in ratio plot.  Default is \code{'black'}.
#' @param plot_series Logical scalar. if TRUE, function will generate a plot of the series first of \code{type='n'}. 
#'                    If FALSE, the ratio will be plotted on the current defined plot. Default is TRUE.
#' @return Generates a high definition plot of rations centered on one, by default.
#' @examples
#' m_air <- seasonal::seas(AirPassengers, transform.function= 'log', arima.model = '(0 1 1)(0 1 1)')
#' air_sf <- seasonal::series(m_air, 's10')
#' plot_ratio(air_sf, main_title = 'SEATS seasonal for Airline Passenger', ratio_color = 'darkblue')
#' @import graphics
#' @import stats
#' @export
plot_ratio <- function(ratio_series = NULL, ratio_range = range(ratio_series), 
    main_title = NULL, main_title_line = 2.75, main_title_cex = 1.25, 
    ratio_mean = 1, ratio_color = NULL, plot_series = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 2.3, 4/21/2022

    # check if \code{ratio_series} is specified
    if (is.null(ratio_series)) {
        stop("Argument ratio_series must be specified.")
    }

    # generate length of the ratio series, time index
    ratio_length <- length(ratio_series)
    ratio.time <- time(ratio_series)

    # plot series frame if \code{plot_series} true
    if (plot_series) {
        plot(ratio_series, type = "n", ylab = " ", xlab = " ", ylim = ratio_range)
        # add main title, if specified.
        if (!is.null(main_title)) {
            mtext(main_title, 3, main_title_line, cex = main_title_cex)
        }
    }

    # add line to plot frame
    if (is.null(ratio_color)) {
        abline(h = ratio_mean)
    } else {
        abline(h = ratio_mean, col = ratio_color)
    }
    
    # add high density plot lines
    for (i in 1:ratio_length) {
        if (is.null(ratio_color)) {
            segments(ratio.time[i], ratio_mean, ratio.time[i], ratio_series[i])
        } else {
            segments(ratio.time[i], ratio_mean, ratio.time[i], ratio_series[i], col = ratio_color)
        }
    }
}
