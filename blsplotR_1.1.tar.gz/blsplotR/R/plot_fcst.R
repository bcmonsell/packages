#' Forecast plot
#'
#' Generates regARIMA forecasts with confidence bounds
#'
#' @param m_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @param main_title Character string; main title of plot.  Default is  \code{'ARIMA Residuals'}.
#' @param do_grid Logical scalar; indicates if certain plots will have grid lines. Default is no grid lines. 
#' @param do_sub Logical scalar; indicates if subtitle is generated. Default is to generate the subtitle. 
#' @param length_ori Integer scalar; number of years of the original series to show with forecasts. Default is 2 years. 
#' @param this_col Array of character strings; color used for original series, forecast, and forecast bounds. Default is \code{c("darkgrey", "blue", "darkgreen")}. 
#' @return Generates a plot of the regARIMA forecasts with confidence bounds.
#' @examples
#' m_air <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)')
#' plot_fcst(m_air, main_title = 'Forecasts for Airline Passengers', do_grid = TRUE)
#' @import graphics
#' @import stats
#' @export
plot_fcst <- function(m_seas = NULL, main_title = "ARIMA forecasts", do_grid = FALSE, do_sub = TRUE, length_ori = 2, 
    this_col = c("darkgrey", "blue", "darkgreen")) {
    # Author: Brian C. Monsell (OEUS) Version 2.7, 3/25/2021
    
    # check if a value is specified for \code{m_seas}
    if (is.null(m_seas)) {
        stop("must specify a seas object")
    }
    
    # extract forecasts, original series
    fcst <- seasonal::series(m_seas, "fct")
    a1 <- seasonal::series(m_seas, "a1")
    
    # get date for end of series
    end_a1 <- end(a1)
    
    # get series to be pottted without forecasts
    srs <- window(a1, start = c(end_a1[1] - length_ori, 1))
    # get series to be pottted with forecasts
    ext <- ts(c(srs, fcst[, 1]), start = start(srs), frequency = frequency(srs))
    
    # generate frame for plot
    plot(ext, main = main_title, ylim = range(ext, fcst[, 2], fcst[, 3]), ylab = " ", xlab = " ", 
        type = "n")
    
    # add lines for plot
    lines(srs, col = this_col[1])
    lines(fcst[, 1], col = this_col[2])
    lines(fcst[, 2], col = this_col[3], lty = 3)
    lines(fcst[, 3], col = this_col[3], lty = 3)
    
    # add grid lines for plot
    if (do_grid) {
        grid()
    }
    
    # generate subtitile
    if (do_sub) {
        aape <- tryCatch(seasonal::udg(m_seas, "aape.0"), error = function(e) {
            NULL
        })
        if (!is.null(aape)) {
            mtext(paste("AAPE Last 3 Years = ", format(aape, digits = 4, nsmall = 2), sep = ""), 3, 
                0.5, cex = 0.75)
        }
    }
}
