#' Plot table from X-13ARIMA-SEATS seasonal adjustment. 
#'
#' Generate plot of user-specified series. 
#'
#' @param this_seas_object \code{seas} object generated from a call of \code{seas} on a single time series
#' @param this_table Character string; X-13ARIMA-SEATS table name or abbreviation. If not a valid table name, the function will print an error message and return a NULL.
#' @param main_title Character string; main title of plot.  Default is  \code{'Cumulative periodogram'}.
#' @param y_label Character string; y-axis label for plot, if specified.
#' @param y_limit Numeric vector of length 2; Range of values you wish the plot to be plotted over. Default is range of the seasonal factors.
#' @param start_plot Integer vector of length 2; Starting date for plot. Default is starting date for the time series. 
#' @param do_grid Logical scalar; indicates if certain plots will have grid lines. Default is no grid lines. 
#' @param draw_recess Logical scalar; indicates if certain plots will have shaded areas for NBER recession dates. Default is no recession shading. 
#' @param recess_start numeric matrix; Rows of dates for additional recession starting and ending dates. Default is not to add recession dates.
#' @param recess_col Character string; color used for shading of recession region. Default is \code{'lightgrey'}.
#' @param recess_sub Logical scalar; indicates if x-axis label for recession is produced for this plot. Default is x-axis label is produced
#' @param add_otl Logical scalar; indicates if lines for identified outliers are included in series plots. Default is not including lines for identified outliers. 
#' @param use_ratio Logical scalar; indicates if plots of seasonal factors, irregular, and residuals are done as ratio plots. Default has these plots as time series line plots.
#' @param add_sub_title Logical scalar; indicates if plots will include subtitles denoting what series are plotted. Default is not including subheaders.
#' @param this_line_type Integer vector; indicates line type of each plot produced. Default is 1:length(this_table)
#' @param this_col Character array of length 6; color used for series in the order specified by the user. Default is \code{c('grey', 'blue', 'green', 'brown', 'red', 'yellow')}. 
#' @param otl_col Character array of length 6; color used for different outliers, with the order being \code{'ao','ls','tc','so','rp','tls'}. Default is \code{c('red', 'blue', 'green', 'brown', 'grey', 'yellow')}. 
#' @return Generate plot of user-specified series. Can be more than one series. If series not specified, print out error message and return NULL.
#' @examples
#' m_air <- 
#'   seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', x11='',
#'                  series.save = 'b1')
#' plot_table(m_air, c('a1', 'b1', 'd11'), y_label = 'AirPassengers', 
#'          do_grid = TRUE, draw_recess = TRUE, use_ratio = TRUE, add_otl = TRUE,
#'          this_col = c('grey', 'darkgreen', 'darkblue'))
#' @import graphics
#' @import stats
#' @export
plot_table <- function(this_seas_object = NULL, this_table = NULL, main_title = NULL,  
    y_label = NULL, y_limit = NULL, start_plot = NULL, do_grid = FALSE, 
    draw_recess = FALSE, recess_start = NULL, recess_col = NULL, recess_sub = TRUE, 
    add_otl = FALSE, use_ratio = FALSE, add_sub_title = FALSE, this_line_type = NULL, 
    this_col = c("grey", "blue", "green", "brown", "red", "yellow"), 
    otl_col = c("red", "blue", "green", "brown", "grey", "yellow")) {
    # Author: Brian C. Monsell (OEUS) Version 3.3, 3/25/2021
    
    # check if a value is specified for \code{this_seas_object}
    if (is.null(this_seas_object)) {
        stop("must specify a seas object")
    }
    
    # check if a value is specified for \code{this_table}
    if (is.null(this_table)) {
        stop("must specify tables to plot")
    }
    
    # Extract series from the X-13 output - if series not specified, print out error message and
    # return NULL
    this_table_length <- length(this_table)
    if (this_table_length == 1) {
        this_series <- tryCatch(seasonal::series(this_seas_object, this_table), error = function(e) {
            print(paste("series not valid:", this_table))
            NULL
        })
    } else {
        this_series <- list()
        for (i in 1:this_table_length) {
            table_i <- this_table[i]
            this_series[[table_i]] <- tryCatch(seasonal::series(this_seas_object, table_i), error = function(e) {
                print(paste("series not valid:", this_table))
                NULL
            })
        }
        if (length(this_series) < this_table_length) {
            this_series <- NULL
        }
    }
    
    if (is.null(this_series)) {
        return()
    }
    
    # If start_plot specified, shorten series
    if (!is.null(start_plot)) {
        if (this_table_length == 1) {
            this_series <- window(this_series, start = start_plot)
        } else {
            this_series <- lapply(this_series, 
                function(x) try(window(x, start = start_plot)))
        }
    }
    
    if (is.null(y_limit)) {
        if (this_table_length == 1) {
            y_limit <- range(this_series)
        } else {
            y_limit <- range(unlist(this_series))
        }
    }
    
    if (is.null(this_line_type)) {
        this_line_type = seq(1, this_table_length)
    }
    
    # If only one series is specified, check to see if this is a ratio plot.
    if (this_table_length == 1) {
        if (use_ratio) {
            # Get transformation, then set value of factor mean.
            this_trans <- seasonal::udg(this_seas_object, "transform")
            if (this_trans == "Automatic selection") {
                this_trans <- seasonal::udg(this_seas_object, "aictrans")
            }
            if (this_trans == "Log(y)") {
                h_bar <- 1
            } else {
                h_bar <- 0
            }
            # Generate ratio plot.
            plot_ratio(this_series, ratio_color = this_col[1], ratio_mean = h_bar)
            
        } else {
            # Generate plot with title.
            plot(this_series, xlab = " ", ylab = " ", type = "n", ylim = y_limit, lty = this_line_type)
            lines(this_series, col = this_col[1])
        }
        mtext(main_title, 3, 2.75, cex = 1.25)
        # add subtitle.
        if (add_sub_title) {
            this_sub_title <- paste(this_table, " = ", this_col[1], sep = "")
            mtext(this_sub_title, 3, 1.5, cex = 0.9)
        }
    } else {
        # Generate plot, adding lines for one series at a time.
        plot(this_series[[1]], xlab = " ", ylab = " ", type = "n", ylim = y_limit)
        for (i in 1:this_table_length) {
            lines(this_series[[i]], col = this_col[i], lty = this_line_type[i])
        }
        # Generate title, add subtitle.
        mtext(main_title, 3, 2.75, cex = 1.25)
        if (add_sub_title) {
            this_sub_title <- ""
            for (i in 1:(length(this_table) - 1)) {
                this_sub_title <- paste(this_sub_title, " ", this_table[i], " = ", this_col[i], ",", 
                  sep = "")
            }
            this_sub_title <- paste(this_sub_title, " ", this_table[length(this_table)], " = ", this_col[length(this_table)], 
                sep = "")
            mtext(this_sub_title, 3, 1.5, cex = 0.9)
        }
    }
    
    # add y-axis label, if specified.
    if (!is.null(y_label)) {
        mtext(y_label, 2, 2.5)
    }
    
    # add grid.
    if (do_grid) {
        grid()
    }
    
    # add shaded regions for recessions.
    if (draw_recess) {
        draw_recession(recess_col, this_add_recess_start = recess_start, 
                       this_sub_recess = recess_sub)
    }
    
    # add lines for outliers.
    if (add_otl) {
        # inititalize outlier codes.
        all_otl <- c("ao", "ls", "tc", "so", "rp", "tls")
        i_otl <- 1:6
        # generate regressors, grab series frequency
        this_reg <- unlist(strsplit(sautilities::get_reg_string(this_seas_object), " "))
        this_freq <- seasonal::udg(this_seas_object, "freq")
        # number of AO, LS, TC, SO, RP, and TLS outliers.
        nAO <- seasonal::udg(this_seas_object, "outlier.ao")
        nLS <- seasonal::udg(this_seas_object, "outlier.ls")
        nTC <- seasonal::udg(this_seas_object, "outlier.tc")
        nSO <- seasonal::udg(this_seas_object, "outlier.so")
        nRP <- seasonal::udg(this_seas_object, "outlier.rp")
        nTLS <- seasonal::udg(this_seas_object, "outlier.tls")
        
        # process each regressor.
        for (i in 1:length(this_reg)) {
            
            # set code for potential outliers
            if (tolower(substr(this_reg[i], 1, 3)) == "tls") {
                this_code <- "tls"
            } else {
                this_code <- tolower(substr(this_reg[i], 1, 2))
            }
            
            # check code to see if the regressor is an outlier
            if (sum(match(all_otl, this_code), na.rm = TRUE) > 0) {
                # process name of regressor to get outlier date(s)
                this_o <- sautilities::proc_outlier(this_reg[i], this_code, this_freq)
                x_otlr <- this_o$year + (this_o$period - 1)/this_freq
                # ypos <- plotLim[4] - (plotLim[4]-plotLim[3])/30
                i_col <- i_otl[all_otl == this_code]
                # draw line for outlier
                if (this_code == "ls" | this_code == "rp" | this_code == "so" | this_code == "tls") {
                  abline(v = x_otlr, lty = 2, col = otl_col[i_col])
                  if (this_code == "rp" | this_code == "tls") {
                    x_otlr <- this_o$year2 + (this_o$period2 - 1)/this_freq
                    abline(v = x_otlr, lty = 2, col = otl_col[i_col])
                  }
                } else {
                  abline(v = x_otlr, lty = 2, col = otl_col[i_col])
                }
            }
        }
        # create sub header for outliers included in plot
        sub_header <- ""
        if (nAO > 0) {
            sub_header <- paste(sub_header, " AO = ", otl_col[1], sep = "")
            if (nLS + nTC + nSO + nRP + nTLS > 0) {
                sub_header <- paste(sub_header, ",", sep = "")
            }
        }
        if (seasonal::udg(this_seas_object, "outlier.ls") > 0) {
            sub_header <- paste(sub_header, " LS = ", otl_col[2], sep = "")
            if (nTC + nSO + nRP + nTLS > 0) {
                sub_header <- paste(sub_header, ",", sep = "")
            }
        }
        if (seasonal::udg(this_seas_object, "outlier.tc") > 0) {
            sub_header <- paste(sub_header, " TC = ", otl_col[3], sep = "")
            if (nSO + nRP + nTLS > 0) {
                sub_header <- paste(sub_header, ",", sep = "")
            }
        }
        if (seasonal::udg(this_seas_object, "outlier.so") > 0) {
            sub_header <- paste(sub_header, " SO = ", otl_col[4], sep = "")
            if (nRP + nTLS > 0) {
                sub_header <- paste(sub_header, ",", sep = "")
            }
        }
        if (seasonal::udg(this_seas_object, "outlier.rp") > 0) {
            sub_header <- paste(sub_header, " RP = ", otl_col[5], sep = "")
            if (nTLS > 0) {
                sub_header <- paste(sub_header, ",", sep = "")
            }
        }
        if (seasonal::udg(this_seas_object, "outlier.tls") > 0) {
            sub_header <- paste(sub_header, " TLS = ", otl_col[6], sep = "")
        }
        
        # print sub header for outliers included in plot
        if (nchar(sub_header) > 0) {
            mtext(sub_header, 1, 2, cex = 0.75)
        }
        
    }
    
}
