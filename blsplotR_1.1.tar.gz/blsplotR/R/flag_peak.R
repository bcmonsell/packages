#' Flag visual significant peaks in spectra
#'
#' Determine positions of visual significant peaks in spectra
#'
#' @param m_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @param spec_type Character string; type of spectrum. Possible values are 'ori','irr','rsd','sa'. 
#' @param spec_freq_code Character string; type of frequency being tested. Possible values are 's' or 't'. 
#' @param max_freq Numeric string; maximum number of frequencies to test. 
#' @return If visually significant peaks found, a numeric vector of the position of the peak frequecies. If no peaks found, 0.
#' @examples
#' m_air <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', x11='')
#' this_flagged_peak_seas <- flag_peak(m_air,'ori','s',5)
#' this_flagged_peak_td <- flag_peak(m_air,'ori','t',2)
#' @export
flag_peak <- function(m_seas, spec_type, spec_freq_code, max_freq) {
    # Author: Brian C. Monsell (OEUS) Version 1.3, September 18, 2020
    
    # Initialize number of significant peaks (sigPeak), vector of significant peaks (sigvec)
    sigPeak <- 0
    sigvec <- array(0, max_freq)
    
    # extract significance level from udg output
    siglevel <- seasonal::udg(m_seas, "siglevel")
    
    # process all frequencies
    for (i in 1:max_freq) {
        # construct key and extracing peak info from udg output
        thisKey <- paste("spc", spec_type, ".", spec_freq_code, i, sep = "")
        thisPeak <- seasonal::udg(m_seas, thisKey)[1]
        
        # if a peak is found see if it is significant
        if (!thisPeak == "nopeak") {
            if (as.numeric(thisPeak) > siglevel) {
                if (length(seasonal::udg(m_seas, thisKey)) > 1) {
                  sigPeak <- sigPeak + 1
                  sigvec[sigPeak] <- seasonal::udg(m_seas, paste(spec_freq_code, i, ".index", sep = ""))
                }
            }
        }
    }
    
    # return either 0 if no peaks found or vector of peak indices
    if (sigPeak == 0) {
        return(0)
    } else {
        return(sigvec[1:sigPeak])
    }
}
