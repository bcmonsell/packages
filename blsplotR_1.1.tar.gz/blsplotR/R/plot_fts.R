#' Final t-statistics for the outlier identification procedure plot
#'
#' Generates a plot of the final t-statistics for the outlier identification procedure.
#'
#' @param m_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @param fts time series matrix containing final outlier t-statistics for all types of outlier specified by the user.
#' @param this_cex Numeric scalar; sets the \code{cex} plotting parameter. Default sets \code{cex = 0.5}.
#' @param start_plot Integer vector of length 2; Starting date for plot. Default is starting date for the time series. 
#' @param main_title Character string; main title of plot.  Default is  \code{'Outlier T-Values'}.
#' @param add_identified_otl Logical scalar; indicates if outlier plots will include identified outliers. Default is not including identified outliers. 
#' @param col_otl Character array of length 3; color used for different outliers, with the order being \code{'ao','ls','tc'}. Default is \code{c('red', 'blue', 'darkgreen')}. 
#' @return Generates a plot of the final t-statistics from the automatic outlier identification procedure.
#' @examples
#' m_air <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', outlier.types = 'all')
#' air_fts_good <- seasonal::series(m_air, "fts")
#' plot_fts(m_air, air_fts_good, main_title = 'Outlier T-Values for Airline Passengers')
#' @import graphics
#' @import stats
#' @export
plot_fts <- function(m_seas = NULL, fts, this_cex = 0.5, start_plot = NULL, main_title = "Outlier T-Values", 
    add_identified_otl = FALSE, col_otl = c("red", "blue", "darkgreen")) {
    # Author: Brian C. Monsell (OEUS) Version 2.11, 3/25/2021
    
    # check if a value is specified for \code{m_seas}
    if (is.null(m_seas)) {
        stop("must specify a seas object")
    }
    
    # Initialize t-statistic data, point labels
    this_fts <- fts
    point_lab <- substr(dimnames(this_fts)[[2]], 3, 4)
    
    # include identified outliers in plot
    if (add_identified_otl) {
        this_auto_outlier <- unlist(strsplit(sautilities::get_auto_outlier_string(m_seas), " "))
        n_iter <- seasonal::udg(m_seas, "addoutlier")
        this_t_vec <- array(0, length(this_auto_outlier))
        for (i in 1:n_iter) {
            this_key <- paste("otlitr", i, "+", sep = ".")
            this_oit <- array(seasonal::udg(m_seas, this_key))
            this_t_vec[!is.na(match(this_auto_outlier, this_oit[1]))] <- as.numeric(this_oit[4])
        }
        for (i in 1:length(this_auto_outlier)) {
            this_out <- this_auto_outlier[i]
            this_type <- substr(this_out, 1, 2)
            this_year <- as.numeric(substr(this_out, 3, 6))
            if (frequency(this_fts) == 12) {
                this_per <- sautilities::get_month_index(substr(this_out, 8, 10))
                this_date <- this_year + (this_per - 1)/12
            }
            # Include code for other frequencies
            this_col <- seq(1, length(point_lab))[!is.na(match(point_lab, this_type))]
            this_row <- seq(1, length(fts[, 1]))[time(fts) == this_date]
            this_fts[this_row, this_col] <- this_t_vec[i]
        }
    }
    
    # get subset of t-statistics if starting date is specified
    if (!is.null(start_plot)) {
        this_fts <- window(this_fts, start = start_plot)
    }
    
    # get absolute maximum value of t-statistics, Maximum Position of each column of the Matrix
    fts_max <- ts(apply(this_fts, 1, sautilities::absmax), start = start(this_fts), frequency = frequency(this_fts))
    fts_index <- cbind(time(this_fts), max.col(abs(this_fts), "first"))
    
    # initialize color vector for outlier points
    col_vec <- array(" ", length(point_lab))
    
    # get critical values for outlier identification
    this_crit_vec <- array(0, length(point_lab))
    for (i in 1:length(point_lab)) {
        if (point_lab[i] == "AO") {
            this_crit <- seasonal::udg(m_seas, "aocrit")
            if (length(this_crit) > 1) {
                this_crit_vec[i] <- as.numeric(this_crit[1])
            }
            col_vec[i] <- col_otl[1]
        }
        if (point_lab[i] == "LS") {
            this_crit <- seasonal::udg(m_seas, "lscrit")
            if (length(this_crit) > 1) {
                this_crit_vec[i] <- as.numeric(this_crit[1])
            }
            col_vec[i] <- col_otl[2]
        }
        if (point_lab[i] == "TC") {
            this_crit <- seasonal::udg(m_seas, "tccrit")
            if (length(this_crit) > 1) {
                this_crit_vec[i] <- as.numeric(this_crit[1])
            }
            col_vec[i] <- col_otl[3]
        }
    }
    
    # Generate plot subheader
    if (length(unique(this_crit_vec)) == 1) {
        this_sub_head <- paste("critical value = ", unique(this_crit_vec), sep = "")
    } else {
        this_sub_head <- paste("critical values = (", paste(this_crit_vec, collapse = " "), ")", sep = " ")
    }
    
    # Generate frame for the t-statistic plot
    plot(fts_max, type = "n", ylab = " ", xlab = " ", main = main_title, sub = this_sub_head, ylim = range(abs(fts_max), 
        this_crit_vec))
    
    # plot points for each type of outlier
    for (i in 1:length(point_lab)) {
        x <- time(fts_max)[fts_index[, 2] == i]
        y <- fts_max[fts_index[, 2] == i]
        text(x, y, labels = point_lab[i], cex = this_cex, col = col_vec[i])
    }
    
    # lines for outlier critical values
    if (length(unique(this_crit_vec)) == 1) {
        abline(h = unique(this_crit_vec), col = "grey")
    } else {
        abline(h = this_crit_vec, col = col_vec)
    }
    
}
