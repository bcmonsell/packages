#' Seasonal factor mean plot
#'
#' Generates a plot of the means of the seasonal factors
#'
#' @param this_sf \code{tis} object of the seasonal factors from a weekly seasonal adjustment
#' @param this_period Character scalar; vector with period number of the observations.
#' @param this_col Character scalar; color used for factor plots. Default is \code{green}.
#' @param y_limit Numeric vector of length 2; Range of values you wish the plot to be plotted over. Default is range of the seasonal factors.
#' @param this_freq integer scalar; time series frequency.
#' @param this_trans Logical scalar; indicates if the adjustment was done with a log transform. Default is TRUE.
#' @param this_title Character string; main title of plot.  Default is  \code{'Mean of Seasonal Factors'}.
#' @param forecast Integer scalar; Number of forecasts appended to the seasonal factors. Default is 0.
#' @param this_type Character string; type of factors plotted.  Default is  \code{'seasonal'}.
#' @param add_line Logical scalar; indicates if this line is being added to an existing plot. Default is FALSE.
#' @param add_legend Logical scalar; indicates if legend is produced for this plot. Default is legend not produced
#' @param this_legend_position Character string; indicates position of legend. Default is \code{'topleft'}.
#' @param this_legend_title Character string; indicates title of legend. Default is \code{'Series'}.
#' @param this_legend_inset Integer scalar; indicates inset for legend. Default is \code{0}.
#' @param this_legend_entry Character array; entries for the lengend. Default is \code{'Srs1'}
#' @param this_legend_col Character array; line colors for legend. Default is \code{'blue'}.
#' @param this_legend_lty Integer array; line types for legend. Default is \code{1}.
#' @param this_legend_cex Numeric scalar; scaling for legend. Default is \code{0.8}.
#' @return Generate plot of the means of seasonal factors by period, or add to existing plot.
#'         If seasonal factors not specified, print out error message and return NULL.
#' @examples
#'  xt_lauto <- seasonal::seas(xt_data_list, slidingspans = "", transform.function = "log",
#'                             arima.model = "(0 1 1)(0 1 1)",
#'                        forecast.maxlead=36, check.print = c( "pacf", "pacfplot" ))
#'  BP_Region_Sf <-
#'   cbind(seasonal::series(xt_lauto$mw1u, "s10"), seasonal::series(xt_lauto$ne1u, "s10"),
#'         seasonal::series(xt_lauto$so1u, "s10"), seasonal::series(xt_lauto$we1u, "s10"))
#'  this_sf_limit <- range(BP_Region_Sf)
#'  plot_sf_mean(BP_Region_Sf[,1], cycle(BP_Region_Sf[,1]),
#'    this_col = 'blue',
#'    y_limit = this_sf_limit,
#'    this_freq = 12,
#'    forecast = 0,
#'    this_title = 'Building Permits Seasonal Means',
#'    add_legend = TRUE,
#'    this_legend_position = "topleft",
#'    this_legend_title = "SF Means",
#'    this_legend_inset = 0,
#'    this_legend_entry = c("MW", "NE", "SO", "WE"),
#'    this_legend_col = c("blue", "red", "green", "purple"),
#'    this_legend_lty = rep(1,4),
#'    this_legend_cex = 0.8)
#'  plot_sf_mean(BP_Region_Sf[,2], cycle(BP_Region_Sf[,2]),
#'    this_col = 'red',
#'    this_freq = 12,
#'    forecast = 0,
#'    add_line = TRUE)
#'  plot_sf_mean(BP_Region_Sf[,3], cycle(BP_Region_Sf[,3]),
#'    this_col = 'green',
#'    this_freq = 12,
#'    forecast = 0,
#'    add_line = TRUE)
#'  plot_sf_mean(BP_Region_Sf[,4], cycle(BP_Region_Sf[,4]),
#'    this_col = 'purple',
#'    this_freq = 12,
#'    forecast=0,
#'    add_line=TRUE)
#' legend("topleft", legend=c('MW', 'NE', 'SO', 'WE'),
#'        col=c('blue', 'red', 'green', "purple"), lty=rep(1,4), cex=0.8)
#' @import graphics
#' @export
plot_sf_mean <- function(this_sf = NULL, this_period = NULL, this_col = "green", y_limit = range(this_sf),
    this_freq, this_trans = TRUE, this_title = "Mean of Seasonal Factors", forecast = 0, this_type = "Seasonal",
    add_line = FALSE, add_legend = FALSE, this_legend_position = "topleft", this_legend_title = "SF Means",
    this_legend_inset = 0, this_legend_entry = "Srs1", this_legend_col = "green", this_legend_lty = 1,
    this_legend_cex = 0.8) {
  # Author: Brian C. Monsell (OEUS), Version 2.5, 3/28/2022

  if (is.null(this_sf)) {
    stop("Argument this_sf must be specified.")
  }

  if (is.null(this_period)) {
    stop("Argument this_period must be specified.")
  }

    # Extract seasonal factors
    sf <- this_sf[1:(length(this_sf) - forecast)]

    if (length(this_period) > length(sf)) {
        period <- this_period[1:(length(this_period) - forecast)]
    } else {
        period <- this_period
    }

    # Initialize vector of seasonal factor means
    this_sf_mean <- array(0, this_freq)

    # Compute seasonal means
    for (i in 1:this_freq) {
        this_sf_mean[i] <- mean(sf[period == i])
    }

    # Add line for seasonal means to plot
    if (add_line) {
        lines(1:this_freq, this_sf_mean, type = "b", col = this_col)
    } else {
        # set value for horizontal line
        if (this_trans) {
            h_bar <- 1
        } else {
            h_bar <- 0
        }
        this_sub <- paste0("Average ", this_type, " Factors")
        if (this_freq == 12) {
            this_sub <- paste0("Average ", this_type, " Factors by Month of Year")
        }
        if (this_freq == 4) {
            this_sub <- paste0("Average ", this_type, " Factors by Quarter of Year")
        }
        if (this_freq == 52 | this_freq == 53) {
            this_sub <- paste0("Average ", this_type, " Factors by Week of Year")
        }
      # Plot seasonal means
        plot(this_sf_mean, type = "b", main = this_title,
             sub = this_sub, ylab = " ", xlab = " ", ylim = y_limit, col = this_col)
        # generate horizontal line
        abline(h = h_bar, col = "grey", lty = 2)
    }

    # add legend to plot
    if (add_legend) {
      legend(this_legend_position, this_legend_entry, title = this_legend_title, inset = this_legend_inset,
             cex = this_legend_cex, col = this_legend_col, lty = this_legend_lty)
    }

}
