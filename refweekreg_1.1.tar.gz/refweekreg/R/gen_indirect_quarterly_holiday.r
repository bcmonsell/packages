#' Generate indirect quarterly holiday adjustments
#'
#' generate indirect quarterly holiday factors and an indirect holiday adjusted series from monthly time series and monthly holiday factors
#'
#' @param this_a1 Real array; ts object of the original series
#' @param this_hol Real array; ts object of the holiday factors
#' @param ratio Logical scalar; if TRUE, holiday factors are assumed to be ratios; otherwise, the factors are assumed to be on the same scale as the original series. Default setting is TRUE.
#' @return list of two ts objects: holadj, which contains the indirect holiday adjusted quarterly series and holfac, the indirect holiday factors
#' @examples
#' n2033157_hol_q_list <- gen_indirect_quarterly_holiday(n2033157_a1, n2033157_hol)
#' @import stats
#' @export
gen_indirect_quarterly_holiday <- function(this_a1, this_hol, ratio = TRUE) {
    # Author: Brian C. Monsell (OEUS), Version 1.0, 1/20/2022
   if (ratio) {
      this_holadj   <- this_a1 / this_hol
   } else {
      this_holadj   <- this_a1 - this_hol
   }

   this_q        <- aggregate.ts(this_a1, nfrequency = 4)
   this_holadj_q <- aggregate.ts(this_holadj, nfrequency = 4)

   if (ratio) {
      this_holfac_q <- this_q / this_holadj_q
   } else {
      this_holadj_q <- this_q - this_holadj_q
   }

   return(list(holadj = this_holadj_q, holfac = this_holfac_q))
}
