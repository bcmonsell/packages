#' At Work Series
#'
#' A time series object of an at work hours series
#'
#' @format A time series object of an at work hours series from January of 2003 to May of 2020
"n2033157_a1"
