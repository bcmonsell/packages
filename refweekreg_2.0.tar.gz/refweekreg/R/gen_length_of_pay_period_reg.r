#' generate length of pay period regressors
#'
#' Generate a version of the length of pay period regressor for monthly series used for some CES series
#'
#' Version 1.1 10/8/2024
#'
#' @param start_year First year of the sequence
#'        This is a required argument.
#' @param end_year Ending year of the sequence
#'        This is a required argument.
#' @param remove_cal_means Logical scalar;
#'        if TRUE, calendar month means are removed from the final regression matrix.
#'        Default setting is TRUE.
#' @return Matrix of a single time series array of a length of pay period regressors starting
#'         in January of \code{start_year} and ending in December of \code{end_year}
#'
#' @author Brian C. Monsell, \email{monsell.brian@@bls.gov} or \email{bcmonsell@@gmail.com}
#'
#' @examples
#' length_pay_reg_cal <-
#'     gen_length_of_pay_period_reg(2006, 2025, remove_cal_means = TRUE)
#' @import stats
#' @export
gen_length_of_pay_period_reg <- function(start_year = NULL, end_year = NULL, remove_cal_means = TRUE) {
  # Author: Brian C. Monsell (OEUS) Version 1.2 10/8/2024

    if (is.null(start_year)) {
        cat("must specify the starting year")
        return(NULL)
    } else {
        if (is.null(end_year)) {
            cat("must specify the ending year")
            return(NULL)
        }
    }

	start_date <- as.Date(paste0(start_year, "-01-01"))
	end_date   <- as.Date(paste0(end_year, "-12-01"))

	this_date_vec <- seq(start_date, end_date, by = "month")
	this_date_wd  <- lubridate::wday(this_date_vec)

	length_of_pay_period_vec <- rep(11, length.out = length(this_date_wd))
	length_of_pay_period_vec[this_date_wd == 0] <- 10
	length_of_pay_period_vec[this_date_wd == 7] <- 10

	length_of_pay_period_vec <- ts(length_of_pay_period_vec, start = c(start_year, 1), frequency = 12)

	if (remove_cal_means) {
		length_of_pay_period_vec <- refweekreg::calendar_mean_adj(length_of_pay_period_vec)
	}

	return(ts(matrix(length_of_pay_period_vec, ncol = 1), start = c(start_year, 1), frequency = 12))

}
