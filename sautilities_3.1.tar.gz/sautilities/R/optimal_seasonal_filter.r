#' Optimal X-11 seasonal moving average selection
#'
#' Determine the optimal X-11 seasonal moving average based on the value of the seasonal moving average coefficient from an airline model.
#'
#' @param this_series A time series object
#' @param aictest a character string with the entries for the \code{regression.aictest} argument to the \code{seas} function 
#'                from the \code{seasonal} package. Default is NULL, AIC testing not done.
#' @param model a character string with the entry for the \code{arima.model} argument to the \code{seas} function 
#'                from the \code{seasonal} package. Default is \code{'(0 1 1)(0 1 1)'}. Model should have a \code{(0 1 1)} seasonal term)
#' @param variables a character string with the entries for the \code{regression.variables} argument to the \code{seas} function 
#'                  from the \code{seasonal} package. Default is NULL, no regressors added.
#' @param outlier logical scalar, if TRUE outlier identification is done in the call to the \code{seas} function 
#'                from the \code{seasonal} package. Default is TRUE.
#' @param trans characater scalar, a character string with the entry for the \code{transform.function} argument to the \code{seas} function, 
#'                  Default is NULL, and the entry \code{auto} will be used.
#' @param missing_code numeric scalar, a number with the entry for the \code{series.missingcode} argument to the \code{seas} function, 
#'                  Default is NULL, no missing value code is used.
#' @param this_xreg numeric matrix, a user defined regressor matrix to be used in the model estimation.
#'                  Default is NULL, no user-defined regressors are used.
#' @param dp_limits logical scalar, if TRUE limits from Deputot and Planas will be used to choose the moving average, 
#'                  else limits from Bell Chow and Chu will be used. Default is TRUE.
#' @param use_msr logical scalar, if TRUE result of MSR selection will be used if model cannot be estimated, 
#'                 otherwise function will return a NULL value. Default is FALSE.
#' @param use_3x15 logical scalar, if TRUE 3x15 seasonal filter will be returned if chosen, 
#'                 otherwise function will return a \code{3x9} value. Default is FALSE.
#' @return The optimal X-11 seasonal filter, unless the airline model cannot be estimated.
#' @examples
#' this_seasonal  <- 
#'    optimal_seasonal_filter(shoes2008, aictest = c('td', 'easter'), use_msr = TRUE)
#' this_seasonal2 <- 
#'    optimal_seasonal_filter(shoes2008, aictest = c('td', 'easter'), dp_limits = FALSE, 
#'                            use_msr = TRUE)
#' @import stats
#' @export
optimal_seasonal_filter <- function(this_series, aictest = NULL, model = "(0 1 1)(0 1 1)", variables = NULL, 
    outlier = TRUE, trans = NULL, missing_code = NULL, this_xreg = NULL, dp_limits = TRUE, use_msr = FALSE, 
    use_3x15 = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 4.1, 5/6/2021
    
    # set option for transformation
    if (is.null(trans)) {
        trans_text <- "auto"
    } else {
        trans_text <- trans
    }
    
    # generate \code{seas} object for the series with an airline model, 
    # user supplied transformation, regressors, and choice of transformation
    if (outlier) {
        this_seas_object <- seasonal::seas(this_series, transform.function = trans_text, x11 = "", 
                arima.model = model, slidingspans = NULL, regression.variables = variables, 
                regression.aictest = aictest, series.missingcode = missing_code, xreg = this_xreg)
    } else {
        this_seas_object <- seasonal::seas(this_series, transform.function = trans_text, x11 = "", 
                arima.model = model, outlier = NULL, slidingspans = NULL, regression.variables = variables, 
                regression.aictest = aictest, series.missingcode = missing_code, xreg = this_xreg)
    }
    
    # extract seasonal theta
    this_seasonal_theta <- 
        get_seasonal_theta(this_seas_object, frequency(this_series), return_string = FALSE)
    
    # choose seasonal filter. If filter chosen, return this value
    this_seasonal_filter <- 
        choose_optimal_seasonal_filter(this_seasonal_theta, dp_limits, use_3x15)
        
    if (!is.null(this_seasonal_filter)) {
        return(this_seasonal_filter)
    }
    
    # if \code{use_msr} is true, extract MSR choice of seasonal factor if UDG keyword not found, 
    # print out error message and set \code{this_seasonal} to NULL
    if (use_msr) {
        this_seasonal_filter <- tryCatch(seasonal::udg(this_seas_object, "sfmsr"), error = function(e) {
            print(paste("this keyword not found: sfmsr", sep = ""))
            NULL
        })
        return(this_seasonal_filter)
    }
    
    return(NULL)
    
}
