#' Update vector.
#'
#' Fill unspecified elements of a vector with the first element of the input series
#'
#' @param this_series Original time series
#' @param this_num Lenght of updated series. Must be more than the length of \code{this_series}.
#' @return an updated vector of length \code{x_num} augmented with the first value of the input series.
#' @examples
#' this_vector <- c(1,2)
#' updated_vector <- update_vector(this_vector, 4)
#' @export
update_vector <- function(this_series, this_num) {
    # Author: Brian C. Monsell (OEUS) Version 2.0, 3/29/2021
    
    if (length(this_series) > this_num) {
        stop("value of this_num must be greater than the length of the input series")
    }

    # intialize vector to hold the updates
    rvec <- array(NA, this_num)

    # set the first \code{length(this_series)} to be equal to this_series
    for (i in 1:length(this_series)) {
         rvec[i] <- this_series[i]
    }

    # fill rest of the vector with x[1]
    this_series_1ong <- length(this_series) + 1
    for (i in this_series_1ong:this_num) {
         rvec[i] <- this_series[1]
    }
    return(rvec)

}
