#' Process list object of numbers
#'
#' Process list object of numbers and return names of elements that are either greater than or less than a limit
#'
#' @param this_list List of numeric values. The elements should be scalars, not arrays.
#' @param this_limit Numeric scalar which serves as the limit of the numbers stored in this_list
#' @param abs_value Logical scalar that indicates whether the absolute value is taken of the numbers before the comparison is made. (default is FALSE)
#' @param greater_than logical object that specified whether the element names returned are greater than or less than the limit specified in this_limit (default is TRUE)
#' @return A vector of list element names where the value in \code{this_list} is greater than or less than the limit specified in \code{this_limit}. If nothing matches, the function will output the string \code{'none'}
#' @examples
#' xt_lauto <- 
#'   seasonal::seas(xt_data_list, slidingspans = '', forecast.maxlead=36, 
#'                             arima.model = "(0 1 1)(0 1 1)",
#'                             transform.function = 'log', x11 = "",
#'                             check.print = c( 'pacf', 'pacfplot' ))
#' xt_lauto_update <- 
#'      Filter(function(x) inherits(x, "seas"), xt_lauto)
#' m7_key     <- get_mq_key('M7')
#' xt_m7_list <- lapply(xt_lauto_update, function(x) try(get_udg_entry(x, m7_key)))
#' xt_m7_pass <- process_list(xt_m7_list, this_limit = 1.0, abs_value = TRUE, greater_than = FALSE)
#' @export
process_list <- function(this_list = NULL, this_limit = NULL, abs_value = FALSE, greater_than = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 2.0, 4/21/2022
    
    # check if a value is specified for \code{this_list}
    if (is.null(this_list)) {
        stop("must specify a list")
    } else {
        if (!is.list(this_list)) {
            stop("must specify a list")
        }
    }
    
    # check if a value is specified for \code{this_limit}
    if (is.null(this_limit)) {
        stop("must specify a limit")
    }
    
    # if \code{abs_value} is true, return the element names on the list that are either greater than or less than
    # in absolute value than \code{this_limit}
    if (abs_value) {
        if (greater_than) {
            this_name <- names(this_list)[abs(unlist(this_list)) > this_limit]
        } else {
            this_name <- names(this_list)[abs(unlist(this_list)) < this_limit]
        }
    } else {
        # else, return the element names on the list that are either greater than or less than \code{this_limit}
        if (greater_than) {
            this_name <- names(this_list)[unlist(this_list) > this_limit]
        } else {
            this_name <- names(this_list)[unlist(this_list) < this_limit]
        }
    }
    
    # return either the names or 'none' if there are no names
    if (length(this_name) > 0) {
        return(this_name)
    } else {
        return("none")
    }
    
}
