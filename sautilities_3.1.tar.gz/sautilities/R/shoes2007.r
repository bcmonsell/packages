#' Retail sales of shoes, 2007
#'
#' A time series object 
#'
#' @format Retail sales of shoes ending in December of 2007
"shoes2007"
