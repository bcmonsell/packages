#' First overall sasonality test from Maravall (2012)
#'
#' Conduct the first overall test for seasonality as laid out in Maravall (2012)
#'
#' @param this_seas \code{seas} object for a single series
#' @param this_series character string; the table used to generate the AR(30) spectrum. Default is "a1".
#' @param take_log logical scalar; indicates if the AR spectrum is generated from the log of the data.
#'                 Default is TRUE.
#' @return A list with 3 elements: QStest (test probability for QS), 
#'         NPtest (test probability for NP),
#'         and result (character string with test result - possible values of either
#'         "evidence of seasonality" and "no evidence of seasonality")
#' @examples
#' air_seas <- seasonal::seas(AirPassengers,
#'                     arima.model='(0 1 1)(0 1 1)',
#'                     forecast.maxlead = 36, slidingspans = '',
#'                     transform.function = 'log')
#' first_test <- overall_seasonal_test_1(air_seas)
#' @export
overall_seasonal_test_1 <- function(this_seas, this_series = "a1", take_log = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 2.2, 4/26/2021

    this_x <- seasonal::series(this_seas, this_series)
    if (take_log) this_x <- log(this_x)

    this_NP     <- NP_test(this_x)
    this_QS     <- 1.0 - as.vector(seasonal::udg(this_seas, "qsori"))[2]

    if (this_QS > 0.99) {
        this_result <- "evidence of seasonality"
    } else {
        if (this_QS > 0.95 && this_NP$cv > 0.95) {
            this_result <- "evidence of seasonality"
        } else {
            this_result <- "no evidence of seasonality"
        }
    }

    return(list(QStest = this_QS, NPtest = this_NP$cv, result = this_result))
}
