#' add outliers to list of \code{seas} object 
#'
#' add outlier arguments to each element of a list of \code{seas} objects 
#'
#' @param seas_obj_list list of seasonal objects  
#' @param new_data_list list of time series objects; updated data sets from the data used to generate \code{seas_obj_list} 
#' @param outlier_span character string; sets the argument \code{outlier.span}
#' @param outlier_types character string; sets the argument \code{outlier.types}
#' @return a list of updated static seas object with outlier arguments included.
#' @examples
#' xt_lauto_old <- 
#'    seasonal::seas(xt_data_old, slidingspans = '', 
#'                       transform.function = 'log', 
#'                       x11 = '', forecast.maxlead=36)
#' xt_outlier_seas <- 
#'    static_with_outlier_list(xt_lauto_old, xt_data_new) 
#' @export
static_with_outlier_list <- function(seas_obj_list = NULL, new_data_list = NULL, 
                                     outlier_span = ",", outlier_types = "ao,ls") {
    # Author: Brian C. Monsell (OEUS) Version 3.2, 4/25/2022
    
    # check if a value is specified for \code{seas_obj_list}
    if (is.null(seas_obj_list)) {
        stop("must specify a list of seas objects")
    } else {
        if (!is.list(seas_obj_list)) {
            stop("must specify a list")
        }
    }
    
    # check if a value is specified for \code{new_data_list}
    if (is.null(new_data_list)) {
        stop("must specify an updated data set")
    } else {
        if (!is.list(new_data_list)) {
            stop("must specify a list")
        }
    }
    
    seas_obj_list_update <- 
        Filter(function(x) inherits(x, "seas"), seas_obj_list)
        
    seas_obj_names <- names(seas_obj_list_update)
    num_names <- length(seas_obj_names)
    
    new_seas_list <- list()
    new_names <- " "
    
    i2 <- 1
    for (i in 1:num_names) {
        this_name <- seas_obj_names[i]
        if (member_of_list(new_data_list, this_name)) {
            this_new_data <- new_data_list[[this_name]]
            new_seas_list[[i2]] <- 
                static_with_outlier(seas_obj_list[[i2]], this_new_data, outlier_span, outlier_types)
            new_names <- paste0(new_names, " ", this_name)
        } else {
            warning(paste0(this_name, " is not a member of the new data list"))
        }
    }
    
    names(new_seas_list) <- strsplit(new_names, split = " ")
    return(new_seas_list)
}
