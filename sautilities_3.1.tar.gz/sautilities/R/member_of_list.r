#' Member of list
#'
#' Determines if a name is a member of a list
#'
#' @param this_list A list of objects
#' @param this_name character string; element name of \code{this_list}
#' @return returns TRUE if \code{this_name} is an element of \code{this_list}, FALSE otherwise
#' @examples
#' xt_lauto <- seasonal::seas(xt_data_list, slidingspans = '', x11 = "",
#'                       transform.function = 'log',
#'                       arima.model = "(0 1 1)(0 1 1)",
#'                       forecast.maxlead=36,
#'                       check.print = c( 'pacf', 'pacfplot' ))
#' if (member_of_list(xt_lauto, 'us24')) {
#'     \dontrun{save_spec_file(xt_lauto$us24, 'us24')}
#' }
#' @export
member_of_list <- function(this_list = NULL, this_name = NULL) {
    # Author: Brian C. Monsell (OEUS) Version 1.3, 4/24/2021

    # check if a value is specified for \code{this_list}
    if (is.null(this_list)) {
        stop("must specify a list of objects")
    } else {
        if (!is.list(this_list)) {
            stop("must specify a list")
        }
    }

    # check if a value is specified for \code{this_name}
    if (is.null(this_name)) {
        stop("must specify a character string")
    }

    return(this_name %in% names(this_list))
}
