#' List element match
#'
#' Returns element of list that matches \code{this_string}
#'
#' @param this_list List of character strings.
#' @param this_string Character string to match against elements of the list, ie, \code{this_string = 'pass'}. 
#'                    Default is 'fail'
#' @return A vector of list element names that match this_string. 
#'         If nothing matches, the function will output the string 'none'
#' @examples
#' test_lauto <- seasonal::seas(xt_data_list, x11 = '', slidingspans = '', 
#'                       arima.model = "(0 1 1)(0 1 1)",
#'                       transform.function = 'log',
#'                       forecast.maxlead=60, 
#'                       check.print = c( 'pacf', 'pacfplot' ))
#' test_lauto_update <- 
#'      Filter(function(x) inherits(x, "seas"), test_lauto)
#' test_acf_test <- lapply(test_lauto_update, function(x) 
#'                         try(acf_test(x, return_this = 'test')))
#' test_acf_fail <- match_list(test_acf_test, 'fail')
#' test_acf_warn <- match_list(test_acf_test, 'warn')
#' test_acf_pass <- match_list(test_acf_test, 'pass')
#' @export
match_list <- function(this_list, this_string = "fail") {
    # Author: Brian C. Monsell (CSRM) Version 3.0, 4/21/2022
    
    # select names of list elements that match this_string
    this_list_names <- names(this_list)[unlist(this_list) == this_string]
    
    # return vector of names or 'none' if no elements match the string
    if (length(this_list_names) > 0) {
        return(this_list_names)
    } else {
        return("none")
    }
}
