#' Model diagnostic summary 
#'
#' Generate a summary of model diagnostics for a single series 
#'
#' @param seas_obj \code{seas} object generated from a call of \code{seas} on a single time series 
#' @param add_aicc logical scalar; add AICC value to the summary
#' @param add_norm logical scalar; add normality statistics to the summary
#' @param add_auto_out logical scalar; add identified automatic outliers to the summary
#' @param return_list logical scalar; return a list rather than a vector
#' @return vector or list of model diagnostics for a given series
#' @examples
#' air_seas <- 
#'    seasonal::seas(AirPassengers, x11='', slidingspans = '', 
#                    transform.function = 'log', arima.model = '(0 1 1)(0 1 1)', 
#'                   regression.aictest = 'td', forecast.maxlead=36, 
#'                   check.print = c( 'pacf', 'pacfplot' ))
#' air_diag <- all_model_diag(air_seas, add_aicc = TRUE, add_norm = TRUE, 
#'                            add_auto_out = TRUE, return_list = TRUE)
#' @export
all_model_diag <- function(seas_obj = NULL, add_aicc = FALSE, add_norm = FALSE, add_auto_out = FALSE, 
    return_list = FALSE) {
    # Author: Brian C. Monsell (OEUS) Version 3.1, October 23, 2020
    
    # check if a value is specified for \code{seas_obj}
    if (is.null(seas_obj)) {
        stop("must specify a seas object")
    }
    
    # get ARIMA Model
    this_model <- seasonal::udg(seas_obj, "arimamdl")
    
    # get number of regressors
    this_nreg <- seasonal::udg(seas_obj, "nreg")
    
    # add automatic outliers, if specified
    if (add_auto_out) {
        this_autoout <- get_udg_entry(seas_obj, "autoout")
        this_autoreg <- " "
        if (is.null(this_autoout)) {
            this_autoout <- 0
        } else {
            this_autoreg <- get_auto_outlier_string(seas_obj)
        }
    }
    
    # generate residual ACF test result
    this_acf_test <- acf_test(seas_obj, return_this = "why")
    
    # generate seasonality test using QS
    this_seasonal_test <- qs_seasonal_test(seas_obj, test_full = TRUE, test_span = FALSE, return_this = "why")
    
    # generate seasonality test using spectral peaks
    this_spec_peak_test <- spec_peak_test(seas_obj, this_spec = "spcori", return_this = "why")
    
    # create summary
    this_summary <- c(this_model, this_nreg, this_acf_test, this_seasonal_test, this_spec_peak_test)
    
    # add aicc, if specified
    if (add_aicc) {
        this_aicc <- seasonal::udg(seas_obj, "aicc")
        this_summary <- c(this_summary, this_aicc)
    }
    
    # add normality statistics, if specified
    if (add_norm) {
        this_a <- get_norm_stat(seas_obj, "a")
        if (!is.null(this_a)) {
            this_summary <- c(this_summary, replace_na(this_a), replace_na(norm_test(seas_obj, "a")))
        }
        this_kurtosis <- get_norm_stat(seas_obj, "kurtosis")
        if (!is.null(this_kurtosis)) {
            this_summary <- c(this_summary, replace_na(this_kurtosis), replace_na(norm_test(seas_obj, 
                "kurtosis")))
        }
        this_skewness <- get_norm_stat(seas_obj, "skewness")
        if (!is.null(this_skewness)) {
            this_summary <- c(this_summary, replace_na(this_skewness), replace_na(norm_test(seas_obj, 
                "skewness")))
        }
    }
    
    # add automatic outliers, if specified
    if (add_auto_out) {
        this_summary <- c(this_summary, this_autoout, this_autoreg)
    }
    
    # create summary list, if requested
    if (return_list) {
        this_summary_list <- vector("list", length(this_summary))
        for (i in 1:length(this_summary)) {
            this_summary_list[[i]] <- this_summary[i]
        }
        
        # initialize a vector of names
        this_names <- c("ARIMA_Model", "Number_of_Reg", "ACF_Test", "Seasonal_QS", "Spec_Peaks")
        
        # add aicc, if specified
        if (add_aicc) {
            this_names <- c(this_names, "AICC")
        }
        
        # add normality statistics, if specified
        if (add_norm) {
            if (!is.null(this_a)) {
                this_names <- c(this_names, "Gearys_a", "a_test")
            }
            if (!is.null(this_kurtosis)) {
                this_names <- c(this_names, "Kurtosis", "Kurtosis_test")
            }
            if (!is.null(this_skewness)) {
                this_names <- c(this_names, "Skewness", "Skewness_test")
            }
        }
        
        # add automatic outliers, if specified
        if (add_auto_out) {
            this_names <- c(this_names, "Number_of_AutoOut", "Auto_Outliers")
        }
        
        # set element names for list
        names(this_summary_list) <- this_names
        
        # convert some elements from characters to numbers.
        this_summary_list$Number_of_Reg <- as.numeric(this_summary_list$Number_of_Reg)
        if (add_aicc) {
            this_summary_list$AICC <- as.numeric(this_summary_list$AICC)
        }
        if (add_norm) {
            if (!is.null(this_a)) {
                this_summary_list$Gearys_a <- as.numeric(this_summary_list$Gearys_a)
            }
            if (!is.null(this_kurtosis)) {
                this_summary_list$Kurtosis <- as.numeric(this_summary_list$Kurtosis)
            }
            if (!is.null(this_skewness)) {
                this_summary_list$Skewness <- as.numeric(this_summary_list$Skewness)
            }
        }
        if (add_auto_out) {
            this_summary_list$Number_of_AutoOut <- as.numeric(this_summary_list$Number_of_AutoOut)
        }
        
        # return list
        return(this_summary_list)
    }
    
    return(this_summary)
    
}
