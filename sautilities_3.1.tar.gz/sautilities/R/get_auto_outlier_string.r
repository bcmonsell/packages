#' Get automatic outlier names
#'
#' Get the names of outliers identified in the \code{seas} object for a single series.
#'
#' @param seas_obj A seas object for a single series generated from the \code{seasonal} package
#' @return Character string containing a summary of the outliers identified in the regARIMA model. If no regressors or automatic outliers in the model, the routine will return a blank character.
#' @examples
#' m_air <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', x11='')
#' this_auto_outlier <- get_auto_outlier_string(m_air)
#' @export
get_auto_outlier_string <- function(seas_obj = NULL) {
    # Author: Brian C. Monsell (OEUS) Version 2.8, October 23, 2020
    
    # check if a value is specified for \code{seas_obj}
    if (is.null(seas_obj)) {
        stop("must specify a seas object")
    }
    
    # Extract number of regressors, number of automatic outliers
    this_nreg <- seasonal::udg(seas_obj, "nreg")
    this_auto_outlier <- seasonal::udg(seas_obj, "autoout")
    
    # Initialize string of names
    this_string <- " "
    
    # If number of regressors equals number of automatic outliers, extract names of outliers
    if (this_nreg == this_auto_outlier) {
        this_string <- get_reg_string(seas_obj)
    } else {
        # If number of automatic outliers greater than zero, get the position of the \code{nreg} code in UDG data
        if (this_auto_outlier > 0) {
            this_reg_index <- get_udg_index(seasonal::udg(seas_obj), "nreg")
            
            # get UDG keywords for individual regressors
            this_reg_names <- names(seas_obj$udg)[seq(1, this_nreg) + this_reg_index]
            
            # split keywords into regressor names and types
            reg_vec <- unlist(strsplit(this_reg_names, "[$]"))[seq(2, 2 * this_nreg, 2)]
            reg_type_vec <- unlist(strsplit(this_reg_names, "[$]"))[seq(1, 2 * this_nreg, 2)]
            
            # extract names of automatic outliers into \code{this_string}
            this_string <- paste(reg_vec[reg_type_vec == "AutoOutlier"], collapse = " ")
        }
    }
    return(this_string)
}
