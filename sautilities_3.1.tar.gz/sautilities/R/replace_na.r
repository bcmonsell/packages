#' Replace NA
#'
#' Replace NA with a string
#'
#' @param this_vec Vector object.
#' @param replace_string Character scalar which replaces the NAs in the vector. Default is 'NA'.
#' @return A vector with all NAs replaced by a character string
#' @examples
#' sample_vec <- c(rnorm(25), NA, rnorm(24))
#' sample_vec_missing  <- replace_na(sample_vec, replace_string = 'Missing')
#' @export
replace_na <- function(this_vec, replace_string = "NA") {
    # Author: Brian C. Monsell (OEUS) Version 1.5, 3/31/2021
    
    # process each element of the vector, replacing NAs with \code{replace_string}
    for (i in 1:length(this_vec)) {
        if (is.na(this_vec[i])) {
            this_vec[i] <- replace_string
        }
    }
    
    return(this_vec)
}
