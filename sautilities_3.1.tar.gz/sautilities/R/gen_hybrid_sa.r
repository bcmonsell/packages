#' Generate a hybrid seasonal adjustment
#'
#' Generates a "hybrid" seasonal adjustment by replacing a span of a multiplicative seasonal adjustment with an additive adjustment
#'
#' @param this_mult_sa time series object of a multiplicative seasonal adjustment
#' @param this_add_sa time series object of an additive seasonal adjustment
#' @param this_start_hybrid integer vector of length 2, start of the span where additive adjustments replace multiplicative adjustment
#' @param this_end_hybrid integer vector of length 2, end of the span where additive adjustments replace multiplicative adjustment
#' @return time series object with hybrid seasonal adjustment
#' @examples
#' air_mult_seas <- seasonal::seas(AirPassengers, transform.function = "log")
#' air_mult_sa   <- seasonal::final(air_mult_seas)
#' air_add_seas  <- seasonal::seas(AirPassengers, transform.function = "none")
#' air_add_sa    <- seasonal::final(air_add_seas)
#' air_hybrid_sa <- gen_hybrid_sa(air_mult_sa, air_add_sa, c(1956,1), c(1956,12))
#' @export
gen_hybrid_sa <- function(this_mult_sa, this_add_sa, this_start_hybrid, this_end_hybrid) {
    # Author: Brian C. Monsell (OEUS) Version 1.6, 12/14/2021
    this_start <- start(this_mult_sa)
    this_end   <- end(this_mult_sa)
    this_freq  <- frequency(this_mult_sa)
    
    before_hybrid_start <- this_start_hybrid - c(0,1)
    if (before_hybrid_start[2] == 0) {
        before_hybrid_start <- this_start_hybrid + c(-1, this_freq)
    }
    
    after_hybrid_end <- this_end_hybrid + c(0,1)
    if (after_hybrid_end[2] > this_freq){
        after_hybrid_end <- after_hybrid_end + c(1, -this_freq)
    }
    
    this_hybrid_sa <- 
       ts(c(window(this_mult_sa, end = before_hybrid_start),
         window(this_add_sa, start = this_start_hybrid, end = this_end_hybrid),
         window(this_mult_sa, start = after_hybrid_end)), start = this_start,
         frequency = this_freq)
         
    return(this_hybrid_sa)
    
}