#' At Work Series Monthly Holiday Factors
#'
#' A time series object of monthly holiday factors from an at work hours series
#'
#' @format A time series object of monthly holiday factors from an at work hours series from January of 2003 to May of 2020
"n2033157_hol"
