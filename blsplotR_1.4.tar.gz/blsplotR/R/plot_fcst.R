#' Forecast plot
#'
#' Generates regARIMA forecasts with confidence bounds
#'
#' @param this_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @param main_title Character string; main title of plot.  Default is  \code{'ARIMA Residuals'}.
#' @param do_grid Logical scalar; indicates if certain plots will have grid lines. Default is no grid lines. 
#' @param do_sub Logical scalar; indicates if subtitle is generated. Default is to generate the subtitle. 
#' @param length_ori Integer scalar; number of years of the original series to show with forecasts. Default is 2 years. 
#' @param this_col Array of character strings; color used for original series, forecast, and forecast bounds. Default is \code{c("darkgrey", "blue", "darkgreen")}. 
#' @param this_plot_cex Numeric scalar; scaling for the plot itself. Default is \code{0.8}.
#' @param this_lab_cex Numeric scalar; scaling for plot labels. Default is the value of \code{this_plot_cex}.
#' @param this_main_cex Numeric scalar; scaling for main plot title. Default is the value of \code{1.0}.
#' @param this_sub_cex Numeric scalar; scaling for plot subtitle. Default is the value of \code{0.7}.
#' @param this_axis_cex Numeric scalar; scaling for plot axis. Default is the value of \code{this_plot_cex}.
#' @param main_title_line Integer scalar; position of main title of plot.  Default is \code{2.25}.
#' @param this_reset Logical scalar; if TRUE, the values of \code{par} are reset. Default is \code{TRUE}.
#' @return Generates a plot of the regARIMA forecasts with confidence bounds.
#' @examples
#' air_seas <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', forecast.maxlead = 60)
#' plot_fcst(air_seas, main_title = 'Forecasts for Airline Passengers', do_grid = TRUE)
#' @import graphics
#' @import stats
#' @export
plot_fcst <- function(this_seas = NULL, main_title = "ARIMA forecasts", do_grid = FALSE, do_sub = TRUE, length_ori = 2, 
                      this_col = c("darkgrey", "blue", "darkgreen"), this_plot_cex = 0.8, 
                      this_lab_cex = NULL, this_main_cex = 1.0, this_sub_cex = 0.7,
                      this_axis_cex = NULL, main_title_line = 2.25, this_reset = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 4.1, 4/25/2023
    
    # set cex values if not set by user
    if (is.null(this_lab_cex)) {
        this_lab_cex <- this_plot_cex
    }
    if (is.null(this_axis_cex)) {
        this_axis_cex <- this_plot_cex
    }
    if (is.null(this_main_cex)) {
        this_main_cex <- this_plot_cex
    }
    if (is.null(this_sub_cex)) {
        this_sub_cex <- this_plot_cex
    }
    
    if (is.null(main_title)) {
        do_sub <- FALSE
    }

    par(cex = this_plot_cex, cex.axis = this_axis_cex, cex.lab = this_lab_cex,
        cex.main = this_main_cex)
        
    # check if a value is specified for \code{this_seas}
    if (is.null(this_seas)) {
        stop("must specify a seas object")
    }
    
    # extract forecasts, original series
    fcst <- seasonal::series(this_seas, "fct")
    a1 <- seasonal::series(this_seas, "a1")
    
    # get date for end of series
    end_a1 <- end(a1)
    
    # get series to be pottted without forecasts
    srs <- window(a1, start = c(end_a1[1] - length_ori, 1))
    # get series to be pottted with forecasts
    ext <- ts(c(srs, fcst[, 1]), start = start(srs), frequency = frequency(srs))
    
    # generate frame for plot
    plot(ext, ylim = range(ext, fcst[, 2], fcst[, 3]), ylab = " ", xlab = " ", type = "n")
    if (!is.null(main_title)) {
        mtext(main_title, 3, main_title_line, cex = this_main_cex)
    }
    
    # add lines for plot
    lines(srs, col = this_col[1])
    lines(fcst[, 1], col = this_col[2])
    lines(fcst[, 2], col = this_col[3], lty = 3)
    lines(fcst[, 3], col = this_col[3], lty = 3)
    
    # add grid lines for plot
    if (do_grid) {
        grid()
    }
    
    # generate subtitile
    if (do_sub) {
        aape <- tryCatch(seasonal::udg(this_seas, "aape.0"), error = function(e) {
            NULL
        })
        if (!is.null(aape)) {
            mtext(paste("AAPE Last 3 Years = ", format(aape, digits = 4, nsmall = 2), sep = ""), 3, 
                0.5, cex = this_sub_cex)
        }
    }
    
    if (this_reset) { reset_par() }
}
