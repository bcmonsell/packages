#' Generate cumulative periodogram of the regARIMA residuals
#'
#' Generates a plot of the cumulative periodogram of the regARIMA residuals
#'
#' @param this_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @param main_title Character string; main title of plot.  Default is  \code{'Cumulative periodogram'}.
#' @param this_plot_cex Numeric scalar; scaling for the plot itself. Default is \code{0.8}.
#' @param this_lab_cex Numeric scalar; scaling for plot labels. Default is the value of \code{this_plot_cex}.
#' @param this_main_cex Numeric scalar; scaling for main plot title. Default is the value of \code{0.9}.
#' @param this_sub_cex Numeric scalar; scaling for plot subtitle. Default is the value of \code{0.65}.
#' @param this_axis_cex Numeric scalar; scaling for plot axis. Default is the value of \code{this_plot_cex}.
#' @param this_reset Logical scalar; if TRUE, the values of \code{par} are reset. Default is \code{TRUE}.
#' @return Generates a plot of the Cumulative periodogram of the regARIMA residuals. Diagnostic information is included in subheaders.
#' @examples
#' air_seas <- seasonal::seas(AirPassengers, transform.function= 'log', arima.model = '(0 1 1)(0 1 1)')
#' plot_cpgram_resid(air_seas, main_title = 'Cumulative periodogram for Airline Passenger Residuals')
#' @import graphics
#' @import stats
#' @export
plot_cpgram_resid <- function(this_seas = NULL, main_title = "Cumulative periodogram",
                              this_plot_cex = 0.8, this_lab_cex = NULL, 
                              this_main_cex = 0.9, this_sub_cex = 0.65,
                              this_axis_cex = NULL, this_reset = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 4.0, 4/25/2023

    # check if a value is specified for \code{this_seas}
    if (is.null(this_seas)) {
        stop("must specify a seas object")
    }
    
    # set cex values if not set by user
    if (is.null(this_lab_cex)) {
        this_lab_cex <- this_plot_cex
    }
    if (is.null(this_axis_cex)) {
        this_axis_cex <- this_plot_cex
    }
    if (is.null(this_main_cex)) {
        this_main_cex <- this_plot_cex
    }
    if (is.null(this_sub_cex)) {
        this_sub_cex <- this_plot_cex
    }

    par(cex = this_plot_cex, cex.axis = this_axis_cex, cex.lab = this_lab_cex,
        cex.main = this_main_cex)
        
    resid <- seasonal::series(this_seas, "rsd")
    cpgram(resid, main = main_title)
    m_acf <- seasonal::series(this_seas, "acf")
    freq <- seasonal::udg(this_seas, "freq")
    
    if (!is.null(main_title)) {
        if (nrow(m_acf) < 2 * freq) {
            sub_header <- paste("LB", freq, "=", format(m_acf[freq, 3], digits = 2, nsmall = 1), ", PV", 
                                freq, "=", format(m_acf[freq, 5], digits = 2, nsmall = 2), sep = "")
        } else {
            f2 <- freq * 2
            sub_header <- 
                paste("LB", freq, "=", format(m_acf[freq, 3], digits = 2, nsmall = 1), ", PV", 
                      freq, "=", format(m_acf[freq, 5], digits = 2, nsmall = 2), ", LB", f2, "=", 
                      format(m_acf[f2, 3], digits = 2, nsmall = 1), ", PV", f2, "=", 
                      format(m_acf[f2, 5], digits = 2, nsmall = 2), sep = "")
        }
        mtext(sub_header, 3, 0.5, cex = this_sub_cex)
    }
    
    if (this_reset) { reset_par() }

}
