#' Residual plot
#'
#' Generates a plot of the regARIMA residuals with diagnostic information
#'
#' @param this_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @param main_title Character string; main title of plot.  Default is  \code{'ARIMA Residuals'}.
#' @param main_title_line Integer scalar; position of main title of plot.  Default is \code{3}.
#' @param main_title_cex Numeric scalar; scaling for main title of plot. Default is \code{this_plot_cex + 0.1}.
#' @param series_name Character scalar; name of the time series used in m.
#' @param do_grid Logical scalar; indicates if certain plots will have grid lines. Default is grid lines plotted.
#' @param draw_recess Logical scalar; indicates if certain plots will have shaded areas for NBER recession dates. Default is recession shading not plotted.
#' @param recess_start numeric matrix; Rows of dates for additional recession starting and ending dates. Default is not to add recession dates.
#' @param recess_col Character string; color used for shading of recession region. Default is \code{'lightgrey'}.
#' @param recess_sub Logical scalar; indicates if x-axis label for recession is produced for this plot. Default is x-axis label is produced
#' @param use_ratio Logical scalar; indicates if plots of seasonal factors, irregular, and residuals are done as ratio plots. Default has these plots as time series line plots.
#' @param this_col Character string; color used for residuals. Default is \code{'green'}.
#' @param this_plot_cex Numeric scalar; scaling for the plot itself. Default is \code{0.8}.
#' @param this_lab_cex Numeric scalar; scaling for plot labels. Default is the value of \code{this_plot_cex}.
#' @param this_axis_cex Numeric scalar; scaling for plot axis. Default is the value of \code{this_plot_cex}.
#' @param this_sub_cex Numeric scalar; scaling for plot labels. Default is the value of \code{0.5}.
#' @param this_mar Numeric vector; set margins for the plot. Default is \code{c(5.1,4,5.1,0.5)}.
#' @param this_reset Logical scalar; if TRUE, the values of \code{par} are reset. Default is \code{TRUE}.
#' @return Generates a plot of the regARIMA residuals with diagnostic information in the sub-headers.
#' @examples
#' air_seas <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)')
#' plot_resid(air_seas, main_title = 'ARIMA Residuals for Airline Passengers', use_ratio = TRUE,
#'            this_col='darkblue')
#' @import graphics
#' @import utils
#' @export
plot_resid <- function(this_seas = NULL, main_title = "ARIMA Residuals", main_title_line = 3,
    main_title_cex = NULL, series_name = NULL, do_grid = TRUE,
    draw_recess = FALSE, recess_start = NULL, recess_col = NULL, recess_sub = TRUE, 
    use_ratio = FALSE, this_col = "green", this_plot_cex = 0.8, this_lab_cex = NULL,
    this_axis_cex = NULL, this_sub_cex = 0.5, this_mar = c(5.1, 4, 5.1, 0.5), 
    this_reset = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 6.3, 4/25/2023

    # check if a value is specified for \code{this_seas}
    if (is.null(this_seas)) {
        stop("must specify a seas object")
    }
    
    # set cex values if not set by user
    if (is.null(this_lab_cex)) {
        this_lab_cex <- this_plot_cex
    }
    if (is.null(this_axis_cex)) {
        this_axis_cex <- this_plot_cex
    }
    if (is.null(main_title_cex)) {
        main_title_cex <- this_plot_cex + 0.1
    }

   # reset par based on user input.
    par(mar = this_mar, cex = this_plot_cex, cex.axis = this_axis_cex,
        cex.lab = this_lab_cex)
        
    # Extract regARIMA residuals
    resid <- seasonal::series(this_seas, "rsd")

    # Generate main plot title
    if (!is.null(series_name)) {
        if (!is.null(main_title)) {
            main_title <- paste(main_title, " for ", series_name)
        }
    }

    # Generate ratio plot of residuals
    if (use_ratio) {
        plot_ratio(resid, ratio_color = this_col, ratio_mean = 0,
                   this_reset = FALSE)
    } else {
        # Generate line plot of residuals
        plot(resid, ylab = " ", xlab = " ", type = "n")
        lines(resid, col = this_col)
    }

    # Generate zero line
    abline(h = 0)

    # Generate title
    if (!is.null(main_title)) {
        mtext(main_title, 3, main_title_line, cex = main_title_cex)
    }
    
    # Generate grid
    if (do_grid) {
        grid()
    }

    # Generate recession region shading
    if (draw_recess) {
        draw_recession(recess_col, this_add_recess_start = recess_start, 
                       this_sub_recess = recess_sub)
    }

    # get residual diagnostics
    thisA <- tryCatch(seasonal::udg(this_seas, "a"), error = function(e) {
        print("Geary''s a not found")
        NULL
    })

    thisKurt <- tryCatch(seasonal::udg(this_seas, "kurtosis"), error = function(e) {
        print("kurtosis not found")
        NULL
    })

    thisSkew <- tryCatch(seasonal::udg(this_seas, "skewness"), error = function(e) {
        print("skewness not found")
        NULL
    })

    # generate subheaders for diagnostics
    sub1 <- NULL
    sub2 <- NULL
    sub3 <- NULL

    if (!is.null(thisA)) {
        if (length(thisA) > 1) {
            sub1 <- paste("Geary's a = ", sprintf("%4.1f", as.numeric(thisA[1])), " (", thisA[2],
                ")", sep = "")
        } else {
            sub1 <- paste("Geary's a = ", sprintf("%4.1f", thisA), sep = "")
        }
    }

    if (!is.null(thisKurt)) {
        if (length(thisKurt) > 1) {
            sub2 <- paste("Excess Kurtosis = ", sprintf("%4.1f", as.numeric(thisKurt[1])), " (", thisKurt[2],
                ")", sep = "")
        } else {
            sub2 <- paste("Excess Kurtosis = ", sprintf("%4.1f", thisKurt), sep = "")
        }
    }

    if (!is.null(thisSkew)) {
        if (length(thisSkew) > 1) {
            sub3 <- paste("Skewness = ", sprintf("%4.1f", as.numeric(thisSkew[1])), " (", thisSkew[2],
                ")", sep = "")
        } else {
            sub3 <- paste("Skewness = ", sprintf("%4.1f", thisSkew), sep = "")
        }
    }

    if (is.null(main_title)) {
        this_sub <- ""
        if (!is.null(sub1)) {
            this_sub <- sub1
        }
        if (!is.null(sub2)) {
            if (is.null(sub1)) {
                this_sub <- sub2
            } else {
                this_sub <- paste0(this_sub, ", ", sub2)
            }
        }
        if (length(this_sub) > 0) {
            if (!is.null(sub3)) {
                mtext(paste0(this_sub, ", ", sub3), 1, 2.5, cex = this_sub_cex)
            } else {
                mtext(this_sub, 1, 2.5, cex = this_sub_cex)
            }
        }
    } else {
        if (!is.null(sub1)) {
            mtext(sub1, 3, 2, cex = this_sub_cex)
        }
        if (!is.null(sub2)) {
            if (!is.null(sub3)) {
                mtext(paste(sub2, ", ", sub3, sep = ""), 3, 1, cex = this_sub_cex)
            } else {
                mtext(sub2, 3, 1, cex = this_sub_cex)
            }
        } else {
            if (!is.null(sub3)) {
                mtext(sub3, 3, 1, cex = this_sub_cex)
            }
        }
    }
    

    # restore graphics parameters
    if (this_reset) { reset_par() }

}
