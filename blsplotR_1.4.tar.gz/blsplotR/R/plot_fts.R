#' Final t-statistics for the outlier identification procedure plot
#'
#' Generates a plot of the final t-statistics for the outlier identification procedure.
#'
#' @param this_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @param fts time series matrix containing final outlier t-statistics for all types of outlier specified by the user.
#' @param this_cex Numeric scalar; sets the \code{cex} plotting parameter. Default sets \code{cex = 0.5}.
#' @param start_plot Integer vector of length 2; Starting date for plot. Default is starting date for the time series. 
#' @param main_title Character string; main title of plot.  Default is  \code{'Outlier T-Values'}.
#' @param add_identified_otl Logical scalar; indicates if outlier plots will include identified outliers. Default is not including identified outliers. 
#' @param col_otl Character array of length 3; color used for different outliers, with the order being \code{'ao','ls','tc'}. Default is \code{c('red', 'blue', 'darkgreen')}. 
#' @param this_plot_cex Numeric scalar; scaling for the plot itself. Default is \code{0.8}.
#' @param this_lab_cex Numeric scalar; scaling for plot labels. Default is the value of \code{this_plot_cex}.
#' @param this_main_cex Numeric scalar; scaling for main plot title. Default is the value of \code{this_plot_cex + 0.1}.
#' @param this_sub_cex Numeric scalar; scaling for plot subtitle. Default is the value of \code{this_plot_cex}.
#' @param this_axis_cex Numeric scalar; scaling for plot axis. Default is the value of \code{this_plot_cex}.
#' @param this_mar Numeric vector; set margins for the plot. Default is \code{c(4.1, 2.1, 4.1, 0.5)}.
#' @param main_title_line Integer scalar; position of main title of plot.  Default is \code{2.25}.
#' @param sub_title_line Integer scalar; position of main title of plot.  Default is \code{1}.
#' @param this_reset Logical scalar; if TRUE, the values of \code{par} are reset. Default is \code{TRUE}.
#' @return Generates a plot of the final t-statistics from the automatic outlier identification procedure.
#' @examples
#' air_seas_outlier <- 
#'     seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', outlier.types = 'all')
#' air_fts_good <- seasonal::series(air_seas_outlier, "fts")
#' plot_fts(air_seas_outlier, air_fts_good, 
#'          main_title = 'Outlier T-Values for Airline Passengers')
#' @import graphics
#' @import stats
#' @export
plot_fts <- function(this_seas = NULL, fts, this_cex = 0.5, start_plot = NULL, main_title = "Outlier T-Values", 
    add_identified_otl = FALSE, col_otl = c("red", "blue", "darkgreen"),
    this_plot_cex = 0.8, this_lab_cex = NULL, this_main_cex = NULL,
    this_sub_cex = NULL, this_axis_cex = NULL, this_mar = c(4.1, 2.1, 4.1, 0.5),
    main_title_line = 2.25, sub_title_line = 1.0, this_reset = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 4.1, 4/27/2023
    
    # check if a value is specified for \code{this_seas}
    if (is.null(this_seas)) {
        stop("must specify a seas object")
    }
    
    # set cex values if not set by user
    if (is.null(this_lab_cex)) {
        this_lab_cex <- this_plot_cex
    }
    if (is.null(this_axis_cex)) {
        this_axis_cex <- this_plot_cex
    }
    if (is.null(this_main_cex)) {
        this_main_cex <- this_plot_cex + 0.1
    }
    if (is.null(this_sub_cex)) {
        this_sub_cex <- this_plot_cex
    }
    par(mar = this_mar, cex = this_plot_cex, cex.axis = this_axis_cex, cex.lab = this_lab_cex)
    
    # Initialize t-statistic data, point labels
    this_fts <- fts
    point_lab <- substr(dimnames(this_fts)[[2]], 3, 4)
    
    # include identified outliers in plot
    if (add_identified_otl) {
        this_auto_outlier <- unlist(strsplit(sautilities::get_auto_outlier_string(this_seas), " "))
        n_iter <- seasonal::udg(this_seas, "addoutlier")
        this_t_vec <- array(0, length(this_auto_outlier))
        for (i in 1:n_iter) {
            this_key <- paste("otlitr", i, "+", sep = ".")
            this_oit <- array(seasonal::udg(this_seas, this_key))
            this_t_vec[!is.na(match(this_auto_outlier, this_oit[1]))] <- as.numeric(this_oit[4])
        }
        for (i in 1:length(this_auto_outlier)) {
            this_out <- this_auto_outlier[i]
            this_type <- substr(this_out, 1, 2)
            this_year <- as.numeric(substr(this_out, 3, 6))
            if (frequency(this_fts) == 12) {
                this_per <- sautilities::get_month_index(substr(this_out, 8, 10))
                this_date <- this_year + (this_per - 1)/12
            }
            # Include code for other frequencies
            this_col <- seq(1, length(point_lab))[!is.na(match(point_lab, this_type))]
            this_row <- seq(1, length(fts[, 1]))[time(fts) == this_date]
            this_fts[this_row, this_col] <- this_t_vec[i]
        }
    }
    
    # get subset of t-statistics if starting date is specified
    if (!is.null(start_plot)) {
        this_fts <- window(this_fts, start = start_plot)
    }
    
    # get absolute maximum value of t-statistics, Maximum Position of each column of the Matrix
    fts_max <- ts(apply(this_fts, 1, sautilities::absmax), start = start(this_fts), frequency = frequency(this_fts))
    fts_index <- cbind(time(this_fts), max.col(abs(this_fts), "first"))
    
    # initialize color vector for outlier points
    col_vec <- array(" ", length(point_lab))
    
    # get critical values for outlier identification
    this_crit_vec <- array(0, length(point_lab))
    for (i in 1:length(point_lab)) {
        if (point_lab[i] == "AO") {
            this_crit <- seasonal::udg(this_seas, "aocrit")
            if (length(this_crit) > 0) {
                this_crit_vec[i] <- as.numeric(this_crit[1])
            }
            col_vec[i] <- col_otl[1]
        }
        if (point_lab[i] == "LS") {
            this_crit <- seasonal::udg(this_seas, "lscrit")
            if (length(this_crit) > 0) {
                this_crit_vec[i] <- as.numeric(this_crit[1])
            }
            col_vec[i] <- col_otl[2]
        }
        if (point_lab[i] == "TC") {
            this_crit <- seasonal::udg(this_seas, "tccrit")
            if (length(this_crit) > 0) {
                this_crit_vec[i] <- as.numeric(this_crit[1])
            }
            col_vec[i] <- col_otl[3]
        }
    }
    
    # Generate frame for the t-statistic plot
    plot(fts_max, type = "n", ylab = " ", xlab = " ", ylim = range(abs(fts_max), this_crit_vec))
    if (!is.null(main_title)) {
    # Generate plot subheader
        if (length(unique(this_crit_vec)) == 1) {
            this_sub_head <- paste("critical value = ", unique(this_crit_vec), sep = "")
        } else {
            this_sub_head <- paste("critical values = (", paste(this_crit_vec, collapse = " "), ")", sep = " ")
        }
    
        mtext(main_title, 3, main_title_line, cex = this_main_cex)
        mtext(this_sub_head, 3, sub_title_line, cex = this_sub_cex)
    }
    
    # plot points for each type of outlier
    for (i in 1:length(point_lab)) {
        x <- time(fts_max)[fts_index[, 2] == i]
        y <- fts_max[fts_index[, 2] == i]
        text(x, y, labels = point_lab[i], cex = this_cex, col = col_vec[i])
    }
    
    # lines for outlier critical values
    if (length(unique(this_crit_vec)) == 1) {
        abline(h = unique(this_crit_vec), col = "grey")
    } else {
        abline(h = this_crit_vec, col = col_vec)
    }
    
    if (this_reset) { reset_par() }
    
}
