#' Ratio plot
#'
#' Generates a high-definition plot around a reference line other than zero.
#'
#' @param ratio_series Time series of ratios/factors for which you want to generate a high definition plot
#' @param ratio_range Range of values you wish the plot to be plotted over. Default is range of the series.
#' @param main_title Title for the plot. Default is character string \code{'Ratio Plot'}.
#' @param main_title_line Integer scalar; position of main title of plot.  Default is \code{2}.
#' @param main_title_cex Numeric scalar; scaling for main title of plot. Default is \code{this_plot_cex + 0.1}.
#' @param ratio_mean Assumed mean value for the ratio.  Default is \code{1.0}
#' @param ratio_color Color used for lines in ratio plot.  Default is \code{'black'}.
#' @param this_plot_cex Numeric scalar; scaling for the plot itself. Default is \code{0.8}.
#' @param this_lab_cex Numeric scalar; scaling for plot labels. Default is the value of \code{this_plot_cex}.
#' @param this_axis_cex Numeric scalar; scaling for plot axis. Default is the value of \code{this_plot_cex}.
#' @param this_mar Numeric vector; set margins for the plot. Default is \code{c(4,4,4,0,5)}.
#' @param this_reset Logical scalar; if TRUE, the values of \code{par} are reset. Default is \code{TRUE}.
#' @param plot_series Logical scalar. if TRUE, function will generate a plot of the series first of \code{type='n'}. 
#'                    If FALSE, the ratio will be plotted on the current defined plot. Default is TRUE.
#' @return Generates a high definition plot of rations centered on one, by default.
#' @examples
#' air_seas <- seasonal::seas(AirPassengers, transform.function= 'log', arima.model = '(0 1 1)(0 1 1)')
#' air_sf <- seasonal::series(air_seas, 's10')
#' plot_ratio(air_sf, main_title = 'SEATS seasonal for Airline Passenger', ratio_color = 'darkblue')
#' @import graphics
#' @import stats
#' @export
plot_ratio <- function(ratio_series = NULL, ratio_range = range(ratio_series), 
                       main_title = NULL, main_title_line = 2, main_title_cex = NULL, 
                       ratio_mean = 1, ratio_color = NULL, this_plot_cex = 0.8, this_lab_cex = NULL,
                       this_axis_cex = NULL, this_mar = c(4,4,4,0.5), this_reset = TRUE,
                       plot_series = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 3.1, 4/25/2023

    # check if \code{ratio_series} is specified
    if (is.null(ratio_series)) {
        stop("Argument ratio_series must be specified.")
    }
    
   # set cex values if not set by user
    if (is.null(this_lab_cex)) {
        this_lab_cex <- this_plot_cex
    }
    if (is.null(this_axis_cex)) {
        this_axis_cex <- this_plot_cex
    }
    if (is.null(main_title_cex)) {
        main_title_cex <- this_plot_cex + 0.1
    }

   # reset par based on user input.
    par(mar = this_mar, cex = this_plot_cex, cex.axis = this_axis_cex,
        cex.lab = this_lab_cex)
   

    # generate length of the ratio series, time index
    ratio_length <- length(ratio_series)
    ratio.time <- time(ratio_series)

    # plot series frame if \code{plot_series} true
    if (plot_series) {
        plot(ratio_series, type = "n", ylab = " ", xlab = " ", ylim = ratio_range)
        # add main title, if specified.
        if (!is.null(main_title)) {
            mtext(main_title, 3, main_title_line, cex = main_title_cex)
        }
    }

    # add line to plot frame
    if (is.null(ratio_color)) {
        abline(h = ratio_mean)
    } else {
        abline(h = ratio_mean, col = ratio_color)
    }
    
    # add high density plot lines
    for (i in 1:ratio_length) {
        if (is.null(ratio_color)) {
            segments(ratio.time[i], ratio_mean, ratio.time[i], ratio_series[i])
        } else {
            segments(ratio.time[i], ratio_mean, ratio.time[i], ratio_series[i], col = ratio_color)
        }
    }
    
    if (this_reset) { reset_par() }
}
