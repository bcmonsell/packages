#' Seasonal factor plot (for up to two sets of factors) grouped by month/quarter
#'
#' Generates a special plot of the seasonal factors grouped by month/quarter. This can be done for up to two sets of seasonal factors.
#'
#' @param this_sf array of seasonal factors stored as a time series
#' @param second_sf array of a second set of seasonal factors stored as a time series. If NULL, a second set of factors is not plotted.
#' @param y_limit Numeric vector of length 2; Range of values you wish the plot to be plotted over. Default is range of the seasonal factors.
#' @param this_trans Logical scalar; indicates if the adjustment was done with a log transform. Default is TRUE.
#' @param main_title Character string; main title of plot.  Default is  \code{'Seasonal Sub-Plots'}.
#' @param this_xlab Character string; label for x-axis of plot.  Default is a blank x-axis.
#' @param this_col Character array of length 4; color used for seasonal factors, second set of seasonal factors, seasonal mean, and second seasonal mean. Default is \code{c("darkgreen", "darkblue", "darkgrey")}.
#' @param first_year Integer scalar; First year used in plot. Default is start of the series.
#' @param add_mean_line Logical scalar; indicates if seasonal factor plots will include lines for seasonal means. Default includes lines for seasonal means.
#' @param this_plot_cex Numeric scalar; scaling for the plot itself. Default is \code{0.8}.
#' @param this_lab_cex Numeric scalar; scaling for plot labels. Default is the value of \code{this_plot_cex}.
#' @param this_main_cex Numeric scalar; scaling for main plot title. Default is the value of \code{this_plot_cex}.
#' @param this_axis_cex Numeric scalar; scaling for plot axis. Default is the value of \code{this_plot_cex}.
#' @param this_mar Numeric vector; set margins for the plot. Default is \code{c(4,4,4,0,5)}.
#' @param add_legend Logical scalar; indicates if legend is produced for this plot. Default is legend not produced
#' @param this_legend_position Character string; indicates position of legend. Default is \code{'topleft'}.
#' @param this_legend_text Array of character strings; indicates text for each seasonal factor in plot. Default is \code{c("SF", "SF Mean")}.
#' @param this_legend_title Character string; indicates title of legend. Default is \code{'Series'}.
#' @param this_legend_inset Integer scalar; indicates inset for legend. Default is \code{0}.
#' @param this_legend_color Array of character strings; indicates color for each seasonal factor in plot. Default is same as \code{this_col}
#' @param this_legend_cex Numeric scalar; scaling for legend. Default is \code{0.8}.
#' @param main_title_line Integer scalar; position of main title of plot.  Default is \code{2.25}.
#' @param this_reset Logical scalar; if TRUE, the values of \code{par} are reset. Default is \code{TRUE}.
#' @return Generates a special plot of the seasonal factors (and the SI-ratios) grouped by month/quarter
#' @examples
#' air_seas       <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', x11='')
#' air_seats_seas <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)')
#' air_sf       <- seasonal::series(air_seas, "d10")
#' air_seats_sf <- seasonal::series(air_seats_seas, "s10")
#' sf_range <- range(air_sf, air_seats_sf)
#' blsplotR::plot_sf_series(air_sf, air_seats_sf, y_limit = sf_range,
#'    add_mean_line = TRUE, add_legend = TRUE,
#'    main_title = 'Air Passengers Seasonal Sub-Plots',
#'    this_col = c('darkgreen', 'darkblue', 'lightgreen', 'lightblue'),
#'    this_legend_text = c("sf(x11)", "sf(seats)", 'mean(x11)', 'mean(seats)'),
#'    this_legend_color = c('darkgreen', 'darkblue', 'lightgreen', 'lightblue'),
#'    main_title_line = 1.25, this_main_cex = 0.95,
#'    this_plot_cex = 0.6, this_axis_cex = 0.75,
#'    this_mar = c(3,3,3,0.5), this_legend_cex = 0.75)
#' #' @import graphics
#' @import stats
#' @export
plot_sf_series <- function(this_sf = NULL, second_sf = NULL, y_limit = NULL, this_trans = TRUE, main_title = "Seasonal Sub-Plots",
    this_xlab = " ", this_col = c("darkgreen", "darkblue", "darkgrey"), 
    first_year = NULL,
    add_mean_line = TRUE, this_plot_cex = 0.8, this_lab_cex = NULL, 
    this_main_cex = NULL, this_axis_cex = NULL, this_mar = c(4,4,4,0.5),
    add_legend = FALSE, this_legend_position = "topleft", this_legend_text = c("SF", "SF Mean"),
    this_legend_title = "SF Plot", this_legend_inset = 0, this_legend_color = this_col,
    this_legend_cex = 0.8, main_title_line = 2.25, this_reset = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 3.6, 5/11/2023

    # check if a value is specified for \code{this_sf}
    if (is.null(this_sf)) {
        stop("must specify at least one set of seasonal factors")
    }

    # Extract cycle and frequency
    sf_period <- cycle(this_sf)
    freq <- frequency(this_sf)
    years <- time(this_sf) %/% 1

    # Set up range of x and y axis.
    if (is.null(y_limit)) {
        y_limit <- range(this_sf)
    }
    x_limit <- seq(0, freq + 1)

    # set cex values if not set by user
    if (is.null(this_lab_cex)) {
        this_lab_cex <- this_plot_cex
    }
    if (is.null(this_axis_cex)) {
        this_axis_cex <- this_plot_cex
    }
    if (is.null(this_main_cex)) {
        this_main_cex <- this_plot_cex
    }

    par(mar = this_mar, cex = this_plot_cex, cex.axis = this_axis_cex, cex.lab = this_lab_cex)

    # Set value of factor mean.
    if (this_trans) {
        h_bar <- 1
    } else {
        h_bar <- 0
    }

    # create the plotting frame, with custom x-axis and create reference line for factor mean.
    plot(x_limit, seq(y_limit[1], y_limit[2], length.out = length(x_limit)), type = "n",
         ylim = y_limit, xlab = this_xlab, ylab = " ", xaxt = "n")
    if (!is.null(main_title)) {
        mtext(main_title, 3, main_title_line, cex = this_main_cex)
    }

    # Generate monthly labels
    if (freq == 12) {
        this_label <-
           c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    } else {
    # Generate quarterly labels
        if (freq == 4) {
            this_label <- paste0("q", 1:4)
        } else {
            this_label <- paste0("p", 1:freq)
        }
    }
    axis(1, at = 1:freq, labels = this_label)
    if (add_mean_line) {
        abline(h = h_bar, col = this_col[3], lty = 2)
    }
    
    # create vector for factor mean.
    this_mu <- array(h_bar, freq)
    if (!is.null(second_sf)) {
        this_mu2 <- array(h_bar, freq)
    }
    
    # loop through each month or quarter.
    for (i in 1:freq) {

        # produce limits for period plot.
        s1 <- (i - 1) + 0.6
        s2 <- i + 0.4

        # save seasonal factors for period i, and generate number of factors.
        sf <- this_sf[sf_period == i]
        this_year <- years[sf_period == i]
        if (!is.null(first_year)) {
          this_filter <- this_year >= first_year
          sf <- sf[this_filter]
        }
        number_sf <- length(sf)
        this_mu[i] <- mean(sf)
        if (!is.null(second_sf)) {
            sf2 <- second_sf[sf_period == i]
            if (!is.null(first_year)) {
                sf2 <- sf2[this_filter]
            }
            this_mu2[i] <- mean(sf2)
        }

        # Generate X values for period i, mean of SF for period i
        this_period_x <- seq(s1, s2, length.out = number_sf)
        
        if (add_mean_line) {
            # Generate line for mean of SF for period i
            segments(s1, this_mu[i], s2, this_mu[i], col = this_col[3])
            if (!is.null(second_sf)) {
                segments(s1, this_mu2[i], s2, this_mu2[i], col = this_col[4])
            }
        }

        # Plot SF for period i
        lines(this_period_x, sf, col = this_col[1])
        if (!is.null(second_sf)) {
            lines(this_period_x, sf2, col = this_col[2])
        }
    }

    # add legend to plot

    if (add_legend) {
        legend(this_legend_position, this_legend_text, title = this_legend_title, 
               inset = this_legend_inset, cex = this_legend_cex, 
               col = this_legend_color, lty = rep(1,length(this_legend_text)))
    }

    if (this_reset) { reset_par() }

}
