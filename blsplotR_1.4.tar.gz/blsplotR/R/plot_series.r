#' Plot individual series.
#'
#' Generate plot of user-specified series.
#'
#' @param this_series Numeric vector; time series object to be plotted.
#' @param main_title Character string; main title of plot.  Default is no title.
#' @param main_title_line Integer scalar; position of main title of plot.  Default is \code{2.75}.
#' @param main_title_cex Numeric scalar; scaling for main title of plot. Default is \code{1.25}.
#' @param y_label Character string; y-axis label for plot, if specified.
#' @param y_limit Numeric vector of length 2; Range of values you wish the plot to be plotted over. Default is range of the seasonal factors.
#' @param start_plot Integer vector of length 2; Starting date for plot. Default is starting date for the time series.
#' @param do_grid Logical scalar; indicates if certain plots will have grid lines. Default is no grid lines.
#' @param draw_recess Logical scalar; indicates if certain plots will have shaded areas for NBER recession dates. Default is no recession shading.
#' @param recess_start numeric matrix; Rows of dates for additional recession starting and ending dates. Default is not to add recession dates.
#' @param recess_col Character string; color used for shading of recession region. Default is \code{'lightgrey'}.
#' @param recess_sub Logical scalar; indicates if x-axis label for recession is produced for this plot. Default is x-axis label is produced
#' @param this_trans Logical scalar; indicates if the adjustment was done with a log transform. Default is TRUE.
#' @param use_ratio Logical scalar; indicates if plots of seasonal factors, irregular, and residuals are done as ratio plots. Default has these plots as time series line plots.
#' @param this_col Character array of length 6; color used for series in the order specified by the user. Default is \code{c('grey', 'blue', 'green', 'brown', 'red', 'yellow')}.
#' @param this_line_type Integer array; line type used for series
#' @param this_point_type Integer array; point type used for series. Default is no points plotted.
#' @param add_legend Logical scalar; indicates if legend is produced for this plot. Default is legend not produced
#' @param this_legend_position Character string; indicates position of legend. Default is \code{'topleft'}.
#' @param this_legend_title Character string; indicates title of legend. Default is \code{'Series'}.
#' @param this_legend_inset Integer scalar; indicates inset for legend. Default is \code{0}.
#' @param this_legend_entry Character array; entries for the lengend. Default is \code{'Srs1'}.
#' @param this_legend_cex Numeric scalar; scaling for legend. Default is \code{0.8}.
#' @param this_legend_col Character string; color of lines in the legend. Default is \code{'grey'}.
#' @param this_legend_lty Numeric scalar; color of lines in the legend. Default is \code{1}.
#' @param this_plot_cex Numeric scalar; scaling for the plot itself. Default is \code{0.8}.
#' @param this_lab_cex Numeric scalar; scaling for plot labels. Default is the value of \code{this_plot_cex}.
#' @param this_axis_cex Numeric scalar; scaling for plot axis. Default is the value of \code{this_plot_cex}.
#' @param this_mar Numeric vector; set margins for the plot. Default is \code{c(4,4,4,0,5)}.
#' @param this_reset Logical scalar; if TRUE, the values of \code{par} are reset. Default is \code{TRUE}.
#' @return Generate plot of user-specified series. Can be first in a series of plots, with other lines or points added after calling this routine. If series not specified, print out error message and return NULL.
#' @examples
#' air_seas <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)',
#'                         outlier.types = "all", x11 = "",
#'                         forecast.maxlead = 36)
#' plot_series(AirPassengers, y_label = 'Air Passengers', do_grid = TRUE,
#'             draw_recess = TRUE, this_col = 'black',
#'             start_plot = c(1958,1), this_point_type = 1,
#'             main_title = "X-11 Seasonal Adjustment for Airline Passengers",
#'             main_title_line = 1.5, main_title_cex = 0.9,
#'             add_legend = TRUE,
#'             this_legend_position = "topleft",
#'             this_legend_title = "Air Passengers", this_legend_inset = 0,
#'             this_legend_entry = c("Series", "SA", "Trend"),
#'             this_legend_col = c("black", "steelblue", "darkgreen"),
#'             this_legend_lty = 1:3,
#'             this_reset = FALSE)
#' lines(window(seasonal::final(air_seas), start=c(1958,1)), col = "blue", lty = 2)
#' lines(window(seasonal::trend(air_seas), start=c(1958,1)), col = "darkgreen", lty = 3)
#' reset_par()
#' @import graphics
#' @import stats
#' @export
plot_series <- function(this_series = NULL, main_title = NULL, main_title_line = 2.75, main_title_cex = 1.25,
                        y_label = NULL, y_limit = NULL, start_plot = NULL, do_grid = FALSE,
                        draw_recess = FALSE, recess_start = NULL, recess_col = NULL, recess_sub = TRUE,
                        this_trans = TRUE, use_ratio = FALSE, this_col = "grey", this_line_type = 1,
                        this_point_type = NULL, add_legend = FALSE, this_legend_position = "topleft", this_legend_title = "Series",
                        this_legend_inset = 0, this_legend_entry = "Srs1", this_legend_cex = 0.8,
                        this_legend_col = "grey", this_legend_lty = 1, this_plot_cex = 0.8, this_lab_cex = NULL,
                        this_axis_cex = NULL, this_mar = c(4,4,4,0.5), this_reset = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 3.10, 5/11/2023

    if (is.null(this_series)) {
        stop("Argument this_series must be specified.")
    }

    # If start_plot specified, shorten series
    if (!is.null(start_plot)) {
        this_series <- window(this_series, start = start_plot)
    }

    if (is.null(y_limit)) {
        y_limit <- range(this_series)
    }

  # set cex values if not set by user
    if (is.null(this_lab_cex)) {
        this_lab_cex <- this_plot_cex
    }
    if (is.null(this_axis_cex)) {
        this_axis_cex <- this_plot_cex
    }

  # reset par based on user input.
    par(mar = this_mar, cex = this_plot_cex, cex.axis = this_axis_cex,
        cex.lab = this_lab_cex)

# Check to see if this is a ratio plot.
    if (use_ratio) {
        if (this_trans) {
            h_bar <- 1
        } else {
            h_bar <- 0
        }
        # Generate ratio plot.
        plot_ratio(this_series, ratio_color = this_col[1], ratio_mean = h_bar)

    } else {
        # Generate plot with title.
        plot(this_series, xlab = " ", ylab = " ", type = "n", ylim = y_limit)
        if (is.null(this_point_type)) {
            lines(this_series, col = this_col[1], lty = this_line_type[1])
        } else {
            lines(this_series, col = this_col[1], lty = this_line_type[1],
                   pch = this_point_type, type = "b")
        }
    }
    # add main title, if specified.
    if (!is.null(main_title)) {
        mtext(main_title, 3, main_title_line, cex = main_title_cex)
    }

    # add y-axis label, if specified.
    if (!is.null(y_label)) {
        mtext(y_label, 2, 2.5)
    }

    # add grid.
    if (do_grid) {
        grid()
    }

    # add shaded regions for recessions.
    if (draw_recess) {
        draw_recession(recess_col, this_add_recess_start = recess_start,
                       this_sub_recess = recess_sub)
    }

    # add legend to plot
    if (add_legend) {
        legend(this_legend_position, this_legend_entry, title = this_legend_title, inset = this_legend_inset,
            cex = this_legend_cex, col = this_legend_col, lty = this_legend_lty)
    }

    if (this_reset) { reset_par() }

}
