#' Generate all diagnostic plots this
#'
#' Generates a series of diagnostic plots from a single \code{seas} object and store the results in a separate file
#'
#' @param this_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @param series_name Character scalar; name of the time series used in this_seas. 
#' @param file_base Character scalar; base file name for the graphics file generated. Default base file name is \code{'BLSplot'}. 
#' @param this_dir Character scalar; directory where the graphics file generated. Default is the current working directory. 
#' @param this_start Integer vector of length 2; Starting date for plot. Default is starting date for the time series. 
#' @param split_plots Logical scalar; indicates if plots will be split into different files. Default is combine the plots into one file. 
#' @param plot_type Character scalar; Type of graphics file generated. Default is \code{'pdf'}. 
#' @param this_grid Logical scalar; indicates if certain plots will have grid lines. Default is no grid lines. 
#' @param this_draw_recess Logical scalar; indicates if certain plots will have shaded areas for NBER recession dates. Default is no recession shading. 
#' @param this_add_recess_start numeric scalar; Starting date for an additional recession period at the end of the series. Default is not to add recession dates.
#' @param this_recess_col Character string; color used for shading of recession region. Default is \code{'lightgrey'}.
#' @param this_recess_sub Logical scalar; indicates if x-axis label for recession is produced for this plot. Default is x-axis label is produced
#' @param this_otl Logical scalar; indicates if lines for identified outliers are included in series plots. Default is not including lines for identified outliers. 
#' @param this_si Logical scalar; indicates if seasonal factor plots will include SI ratios for X-11 seasonal adjustments. Default is not including SI ratios.
#' @param this_mean_line Logical scalar; indicates if seasonal factor plots will include lines for seasonal means. Default includes lines for seasonal means.
#' @param this_specturm_axis Logical scalar; indicates if x-axis of spectral plot will be frequency by month rather than the actual frequencies. Default sets x-axis to frequency by month.
#' @param this_ratio Logical scalar; indicates if plots of seasonal factors, irregular, and residuals are done as ratio plots. Default has these plots as time series line plots.
#' @param this_add_identified_otl Logical scalar; indicates if outlier plots will include identified outliers. Default is not including identified outliers. 
#' @param this_sub_title Logical scalar; indicates if certain plots will include subtitles denoting what series are plotted. Default is not including subheaders.
#' @param col_ori Character scalar; color used for the original series. Default is \code{grey}. 
#' @param col_sa Character scalar; color used for the seasonally adjusted series. Default is \code{forestgreen}. 
#' @param col_one Character scalar; color used for individual series. Default is \code{blue}. 
#' @param col_factor Character scalar; color used for factor plots. Default is \code{forestgreen}. 
#' @param col_fcst Array of character strings; color used for original series, forecast, and forecast bounds. Default is \code{c('grey', 'forestgreen', 'red')}. 
#' @param col_otl Character aray of length 6; color used for different outliers, with the order being \code{'ao','ls','tc','so','rp','tls'}. Default is \code{c('red', 'blue', 'forestgreen', 'brown', 'grey', 'yellow')}. 
#' @param col_sf Character aray of length 3; color used for special seasonal plots, with the order being seasonal factors, SI ratio, seasonal mean. Default is \code{c('forestgreen', 'darkblue', 'grey')}. 
#' @param col_spec Character array of length 6; color used in specturm plots, in the order of spectrum of ori, spectrum of SA, line for seasonal frequency, line for TD frequency, star for visually significant seasonal frequency, star for visually significant TD frequency. Default is \code{c('blue', 'forestgreen', 'grey', 'brown', 'red', 'orange')}. 
#' @param this_plot_cex Numeric scalar; scaling for the plot itself. Default is \code{0.8}.
#' @param this_lab_cex Numeric scalar; scaling for plot labels. Default is the value of \code{this_plot_cex}.
#' @param this_axis_cex Numeric scalar; scaling for plot axis. Default is the value of \code{this_plot_cex}.
#' @param this_otl_cex Numeric scalar; sets the \code{cex} plotting parameter for the fts plot. Default sets \code{cex = 0.5}.
#' @param main_title_cex Numeric scalar; scaling for main title of plot. Default is \code{this_plot_cex + 0.1}.
#' @param sub_title_cex Numeric scalar; scaling for subtitle of plot. Default is \code{this_plot_cex - 0.1}.
#' @param this_mar Numeric vector; set margins for the plot. Default is \code{c(4,4,4,0,5)}.
#' @param this_reset Logical scalar; if TRUE, the values of \code{par} are reset. Default is \code{FALSE}.
#' @return Graphics file with number of diagnostic plots routinely used at BLS.
#' @examples
#' air_seas <- 
#'   seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', 
#'       forecast.maxlead = 60, x11='',
#'       check.print = c("none", "+acf", "+acfplot", "+normalitytest"))
#' 
#' blsplotR::plot_all(air_seas, series_name = 'AirPassengers', 
#'          file_base = 'AirPass', this_dir = 'X:/seasonalAdj/graphs/',
#'          split_plots = TRUE, plot_type = 'png', this_grid = FALSE,
#'          this_draw_recess = FALSE, 
#'          this_ratio = TRUE, this_add_identified_otl = TRUE,
#'          col_sa = 'darkred', col_one = 'steelblue')
#' 
#' blsplotR::plot_all(air_seas, series_name = 'AirPassengers', 
#'          file_base = 'AirPass', this_dir = 'X:/seasonalAdj/graphs/',
#'          this_grid = TRUE, 
#'          this_ratio = TRUE, this_add_identified_otl = TRUE,
#'          col_factor = 'darkorange', 
#'          col_fcst = c('steelblue', 'forestgreen', 'darkred'),
#'          col_sa = 'orange', col_one = 'violet')
#' @export
plot_all <- function(this_seas = NULL, series_name = NULL, file_base = NULL, this_dir = NULL, this_start = NULL, split_plots = FALSE, 
    plot_type = "pdf", this_grid = FALSE, this_draw_recess = FALSE, this_add_recess_start = NULL, this_recess_col = NULL,
    this_recess_sub = TRUE, this_otl = FALSE, this_si = FALSE, 
    this_mean_line = TRUE, this_specturm_axis = TRUE, this_ratio = FALSE, this_add_identified_otl = FALSE, 
    this_sub_title = FALSE, col_ori = "grey", col_sa = "forestgreen", col_one = "steelblue", col_factor = "forestgreen", 
    col_fcst = c("grey", "forestgreen", "red"), col_otl = c("red", "blue", "forestgreen", "brown", "grey", "yellow"), 
    col_sf = c("forestgreen", "darkblue", "grey"), col_spec = c("blue", "forestgreen", "grey", "brown", "red", "orange"),
    this_plot_cex = 0.8, this_lab_cex = NULL, this_axis_cex = NULL, this_otl_cex = 0.5, main_title_cex = NULL,
    sub_title_cex = NULL, this_mar = c(4,4,4,0.5), this_reset = FALSE) {
    # Author: Brian C. Monsell (OEUS) Version 5.3, 5/3/2023
    
    # check if a value is specified for \code{this_seas}
    if (is.null(this_seas)) {
        stop("must specify a seas object")
    }
    
    # Set indicator variable for SEATS seasonal adjustment
    if (substr(seasonal::udg(this_seas, "samode"), 1, 5) == "SEATS") {
        this_seats <- 1
    } else {
        this_seats <- 0
    }
    
    # Initialize Y label
    this_Y_label <- " "
    if (!is.null(series_name)) {
        this_Y_label <- series_name
    }
    
    # Generate time series matrix of final outlier t-statistics, or NA if not available
    this_fts <- seasonal::series(this_seas, "fts")
    
    # Generate base file name if not specified
    if (is.null(file_base)) {
        file_base <- "BLSplot"
    }
    if (is.null(this_dir)) {
        this_dir <- getwd()
    }
    
  # set cex values if not set by user
    if (is.null(this_lab_cex)) {
        this_lab_cex <- this_plot_cex
    }
    if (is.null(this_axis_cex)) {
        this_axis_cex <- this_plot_cex
    }
    if (is.null(main_title_cex)) {
        main_title_cex <- this_plot_cex + 0.1
    }
    if (is.null(sub_title_cex)) {
        sub_title_cex <- this_plot_cex - 0.1
    }

    # Generate separate files for each plot
    if (split_plots) {
        
        # Set up file tags, table names for series vs SA plot
        if (!is.na(series_name)) {
            this_tag <- c(series_name, "OvSA")
        } else {
            this_tag <- "OvSA"
        }
        if (this_seats > 0) {
            this_table <- c("a1", "s11")
        } else {
            this_table <- c("a1", "d11")
        }
        # Generate series vs SA plot, save in graphics file
        R.devices::devEval(plot_type, name = file_base, tags = this_tag, sep = "_", path = this_dir, {
            plot_table(this_seas, this_table, main_title = "Unadjusted vs SA", main_title_cex = main_title_cex, 
                y_label = this_Y_label, start_plot = this_start, do_grid = this_grid, draw_recess = this_draw_recess, 
                recess_start = this_add_recess_start, recess_col = this_recess_col, recess_sub = this_recess_sub, 
                add_otl = this_otl, use_ratio = FALSE, add_sub_title = TRUE, sub_title_cex = sub_title_cex, 
                this_col = c(col_ori, col_sa), otl_col = col_otl, this_plot_cex = this_plot_cex, 
                this_lab_cex = this_lab_cex, this_axis_cex = this_axis_cex, this_mar = this_mar, this_reset = FALSE)
        })
        
        # Set up file tags, table names for trend plot
        if (!is.na(series_name)) {
            this_tag <- c(series_name, "Trn")
        } else {
            this_tag <- "Trn"
        }
        if (this_seats > 0) {
            this_table <- "s12"
        } else {
            this_table <- "d12"
        }
        # Generate trend plot, save in graphics file
        R.devices::devEval(plot_type, name = file_base, tags = this_tag, sep = "_", path = this_dir, {
            plot_table(this_seas, this_table, main_title = "Historical Trend", main_title_cex = main_title_cex,
                y_label = this_Y_label, start_plot = this_start, do_grid = this_grid, draw_recess = this_draw_recess, 
                recess_start = this_add_recess_start, recess_col = this_recess_col, recess_sub = this_recess_sub, 
                add_otl = this_otl, use_ratio = FALSE, add_sub_title = this_sub_title, sub_title_cex = sub_title_cex, 
                this_col = col_one, otl_col = col_otl, this_plot_cex = this_plot_cex, this_lab_cex = this_lab_cex, 
                this_axis_cex = this_axis_cex, this_mar = this_mar, this_reset = FALSE)
        })
        
        # Set up file tags for special seasonal factor plot
        if (!is.na(series_name)) {
            this_tag <- c(series_name, "sPlot")
        } else {
            this_tag <- "sPlot"
        }
        # Generate special seasonal factor plot, save in graphics file
        R.devices::devEval(plot_type, name = file_base, tags = this_tag, sep = "_", path = this_dir, {
            plot_sf(this_seas, add_si = this_si, this_col = col_sf, add_mean_line = this_mean_line, 
                    this_reset = FALSE)
        })
        
        # Set up file tags, table names for sesonal plot
        if (!is.na(series_name)) {
            this_tag <- c(series_name, "Sf")
        } else {
            this_tag <- "Sf"
        }
        if (this_seats > 0) {
            this_table <- "s10"
        } else {
            this_table <- "d10"
        }
        # Generate seasonal factor plot, save in graphics file
        R.devices::devEval(plot_type, name = file_base, tags = this_tag, sep = "_", path = this_dir, {
            plot_table(this_seas, this_table, main_title = "Historical Seasonal Factors", main_title_cex = main_title_cex,
                y_label = this_Y_label, start_plot = this_start, do_grid = this_grid, draw_recess = this_draw_recess, 
                recess_start = this_add_recess_start, recess_col = this_recess_col, recess_sub = this_recess_sub, 
                add_otl = FALSE, use_ratio = this_ratio, add_sub_title = this_sub_title, sub_title_cex = sub_title_cex, 
                this_col = col_factor, this_plot_cex = this_plot_cex, this_lab_cex = this_lab_cex, 
                this_axis_cex = this_axis_cex, this_mar = this_mar, this_reset = FALSE)
        })
        
        # Set up file tags, table names for irregular plot
        if (!is.na(series_name)) {
            this_tag <- c(series_name, "Irr")
        } else {
            this_tag <- "Irr"
        }
        if (this_seats > 0) {
            this_table <- "s13"
        } else {
            this_table <- "d13"
        }
        # Generate irregular plot, save in graphics file
        R.devices::devEval(plot_type, name = file_base, tags = this_tag, sep = "_", path = this_dir, {
            plot_table(this_seas, this_table, main_title = "Historical Irregular", main_title_cex = main_title_cex,
                y_label = this_Y_label, start_plot = this_start, do_grid = this_grid, draw_recess = this_draw_recess, 
                recess_start = this_add_recess_start, recess_col = this_recess_col, recess_sub = this_recess_sub,
                add_otl = FALSE, use_ratio = this_ratio, add_sub_title = this_sub_title, sub_title_cex = sub_title_cex, 
                this_col = col_factor, this_plot_cex = this_plot_cex, this_lab_cex = this_lab_cex, 
                this_axis_cex = this_axis_cex, this_mar = this_mar, this_reset = FALSE)
        })
        
        # Set up title for forecast plot
        if (is.na(series_name)) {
            this_title <- "ARIMA forecasts"
        } else {
            this_title <- paste("ARIMA forecasts for ", series_name, sep = "")
        }
        # Set up file tags for forecast plot
        if (!is.na(series_name)) {
            this_tag <- c(series_name, "Fct")
        } else {
            this_tag <- "Fct"
        }
        # Generate forecast plot, save in graphics file
        R.devices::devEval(plot_type, name = file_base, tags = this_tag, sep = "_", path = this_dir, {
            plot_fcst(this_seas, main_title = this_title, this_main_cex = main_title_cex, 
                 do_grid = this_grid, this_col = col_fcst, this_reset = FALSE)
        })
        
        # Set up file tags for double spectrum plot
        if (!is.na(series_name)) {
            this_tag <- c(series_name, "Spec")
        } else {
            this_tag <- "Spec"
        }
        # Generate double spectrum plot, save in graphics file
        R.devices::devEval(plot_type, name = file_base, tags = this_tag, sep = "_", path = this_dir, {
            plot_double_spectrum(this_seas, xaxis_bls = this_specturm_axis, series_name = series_name, 
                this_col = col_spec, this_reset = FALSE)
        })
        
        # Check to see if outlier t-test matrix was generated
        if (length(this_fts) > 1) {
            # Set up title for Outlier T-Values
            if (is.na(series_name)) {
                this_title <- "Outlier T-Values"
            } else {
                this_title <- paste("Outlier T-Values for ", series_name, sep = "")
            }
            # Set up file tags for outlier T-test plot
            if (!is.na(series_name)) {
                this_tag <- c(series_name, "oTval")
            } else {
                this_tag <- "oTval"
            }
            # Generate outlier T-test plot, save in graphics file
            R.devices::devEval(plot_type, name = file_base, tags = this_tag, sep = "_", path = this_dir, {
                plot_fts(this_seas, this_fts, this_cex = this_otl_cex, main_title = this_title, 
                     this_main_cex = main_title_cex, start_plot = this_start, 
                     add_identified_otl = this_add_identified_otl, col_otl = col_otl[1:3], 
                     this_reset = FALSE)
            })
        }
        
        # Set up file tags for regARIMA residual plot
        if (!is.na(series_name)) {
            this_tag <- c(series_name, "Rsd")
        } else {
            this_tag <- "Rsd"
        }
        # Generate regARIMA residual plot, save in graphics file
        R.devices::devEval(plot_type, name = file_base, tags = this_tag, sep = "_", path = this_dir, {
            plot_resid(this_seas, series_name = series_name, do_grid = this_grid, 
                draw_recess = this_draw_recess, recess_start = this_add_recess_start, 
                recess_col = this_recess_col, recess_sub = this_recess_sub,
                use_ratio = this_ratio, this_col = col_factor, this_reset = FALSE)
        })
        
        # Set up title for Cumulative Periodogram
        if (is.na(series_name)) {
            this_title <- "Cumulative Periodogram"
        } else {
            this_title <- paste("Cumulative Periodogram for ", series_name, sep = "")
        }
        # Set up file tags for Cumulative Periodogram
        if (!is.na(series_name)) {
            this_tag <- c(series_name, "Rcp")
        } else {
            this_tag <- "Rcp"
        }
        # Generate Cumulative Periodogram, save in graphics file
        R.devices::devEval(plot_type, name = file_base, tags = this_tag, sep = "_", path = this_dir, {
            plot_cpgram_resid(this_seas, main_title = this_title, this_reset = FALSE)
        })
        
    } else {
        # Set up file tags for all plots - all plots will be in one file
        this_tag <- "all"
        if (!is.na(series_name)) {
            this_tag <- c(series_name, "all")
        }
        
        # open graphics file to store plots
        R.devices::devEval(plot_type, name = file_base, tags = this_tag, sep = "_", path = this_dir, {
            # Set up table names for original vs SA plot
            if (this_seats > 0) {
                this_table <- c("a1", "s11")
            } else {
                this_table <- c("a1", "d11")
            }
            # Generate original vs SA plot
            plot_table(this_seas, this_table, main_title = "Unadjusted vs SA", main_title_cex = main_title_cex, 
                y_label = this_Y_label, start_plot = this_start, do_grid = this_grid, draw_recess = this_draw_recess, 
                recess_start = this_add_recess_start, recess_col = this_recess_col, 
                recess_sub = this_recess_sub, add_otl = this_otl, use_ratio = FALSE, 
                add_sub_title = TRUE, sub_title_cex = sub_title_cex, this_col = c(col_ori, col_sa), otl_col = col_otl,
                this_plot_cex = this_plot_cex, this_lab_cex = this_lab_cex, this_axis_cex = this_axis_cex, 
                this_mar = this_mar, this_reset = FALSE)
            
            # Set up table names for trend plot
            if (this_seats > 0) {
                this_table <- "s12"
            } else {
                this_table <- "d12"
            }
            # Generate trend plot
            plot_table(this_seas, this_table, main_title = "Historical Trend", main_title_cex = main_title_cex, 
                y_label = this_Y_label, start_plot = this_start, do_grid = this_grid, draw_recess = this_draw_recess, 
                recess_start = this_add_recess_start, add_otl = this_otl, use_ratio = FALSE, 
                add_sub_title = this_sub_title, sub_title_cex = sub_title_cex, this_col = col_one, otl_col = col_otl,
                this_plot_cex = this_plot_cex, this_lab_cex = this_lab_cex, this_axis_cex = this_axis_cex, 
                this_mar = this_mar, this_reset = FALSE)
            
            # Generate special seasonal factor plot
            plot_sf(this_seas, add_si = this_si, this_col = col_sf, add_mean_line = this_mean_line, this_reset = FALSE)
            
            # Set up table names for seasonal plot
            if (this_seats > 0) {
                this_table <- "s10"
            } else {
                this_table <- "d10"
            }
            # Generate seasonal factor plot
            plot_table(this_seas, this_table, main_title = "Historical Seasonal Factors", main_title_cex = main_title_cex, 
                y_label = this_Y_label, start_plot = this_start, do_grid = this_grid, draw_recess = this_draw_recess, 
                recess_start = this_add_recess_start, recess_col = this_recess_col, recess_sub = this_recess_sub, 
                add_otl = FALSE, use_ratio = this_ratio, add_sub_title = this_sub_title, sub_title_cex = sub_title_cex, 
                this_col = col_factor, this_plot_cex = this_plot_cex, this_lab_cex = this_lab_cex, this_axis_cex = this_axis_cex, 
                this_mar = this_mar, this_reset = FALSE)
            
            # Set up table names for irregular plot
            if (this_seats > 0) {
                this_table <- "s13"
            } else {
                this_table <- "d13"
            }
            # Generate irregular plot
            plot_table(this_seas, this_table, main_title = "Historical Irregular Factors", main_title_cex = main_title_cex, 
                y_label = this_Y_label, start_plot = this_start, do_grid = this_grid, draw_recess = this_draw_recess, 
                recess_start = this_add_recess_start, recess_col = this_recess_col, recess_sub = this_recess_sub, 
                add_otl = FALSE, use_ratio = this_ratio, add_sub_title = this_sub_title, sub_title_cex = sub_title_cex, 
                this_col = col_factor, this_plot_cex = this_plot_cex, this_lab_cex = this_lab_cex, this_axis_cex = this_axis_cex, 
                this_mar = this_mar, this_reset = FALSE)
            
            # Set up title for forecast plot
            if (is.na(series_name)) {
                this_title <- "ARIMA forecasts"
            } else {
                this_title <- paste("ARIMA forecasts for ", series_name, sep = "")
            }
            # Generate forecast plot
            plot_fcst(this_seas, main_title = this_title, this_main_cex = main_title_cex, 
                 do_grid = this_grid, this_col = col_fcst, this_reset = FALSE)
            
            # Generate double spectrum plot
            plot_double_spectrum(this_seas, xaxis_bls = this_specturm_axis, series_name = series_name, 
                this_col = col_spec, this_reset = FALSE)
            
            # Generate outlier T-test plot Set up title for Outlier T-Values
            if (length(this_fts) > 1) {
                if (is.na(series_name)) {
                  this_title <- "Outlier T-Values"
                } else {
                  this_title <- paste("Outlier T-Values for ", series_name, sep = "")
                }
                plot_fts(this_seas, this_fts, this_cex = this_otl_cex, main_title = this_title, 
                     this_main_cex = main_title_cex, start_plot = this_start, 
                     add_identified_otl = this_add_identified_otl, col_otl = col_otl[1:3], 
                     this_reset = FALSE)
            }
            
            # Generate regARIMA residual plot, save in graphics file
            plot_resid(this_seas, series_name = series_name, do_grid = this_grid, 
                draw_recess = this_draw_recess, recess_start = this_add_recess_start, 
                recess_col = this_recess_col, recess_sub = this_recess_sub, 
                use_ratio = this_ratio, this_col = col_factor, this_reset = FALSE)
            
            # Set up title for Cumulative Periodogram
            if (is.na(series_name)) {
                this_title <- "Cumulative Periodogram"
            } else {
                this_title <- paste("Cumulative Periodogram for ", series_name, sep = "")
            }
            # Generate Cumulative Periodogram, save in graphics file
            plot_cpgram_resid(this_seas, main_title = this_title, this_reset = FALSE)
        })
    }
    
    # reset graphics settings
    if (this_reset) { reset_par() }

}
