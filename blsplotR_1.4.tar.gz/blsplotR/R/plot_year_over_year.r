#' Year over year plot of individual series.
#'
#' Generate plot of user-specified series with each year as a separate line.
#'
#' @param this_series Numeric vector; time series object to be plotted.
#' @param main_title Character string; main title of plot.  Default is no title.
#' @param main_title_line Integer scalar; position of main title of plot.  Default is \code{1.75}.
#' @param main_title_cex Numeric scalar; scaling for main title of plot. Default is \code{this_plot_cex + 0.1}.
#' @param this_col Character array; color used for series in the order specified by the user.
#'        This array should be as long as the number of years plotted.
#'        If only one color is specified, \code{colortools::wheel(this_col)} is used to construct
#'        an array with enough colors.
#'        Default is \code{rainbow(ny)}, where \code{ny} is the number of years plotted.
#' @param start_plot Integer vector of length 2; Starting date for plot. Default is starting date for the time series.
#' @param this_legend Logical scalar; indicates if a legend is produced for the plot. Default is TRUE.
#' @param this_legend_cex Numeric scalar; scaling for legend. Default is \code{0.75}.
#' @param this_right_mar Numeric scalar; value associated with the margin of the right y-axis specified in the \code{mar} entry of the graphics parameters (\code{par}). 
#'        Default is \code{5.25}.
#' @param this_legend_inset Numeric scalar; value associated with the inset of the right legend.
#'        Default is \code{-0.15}.
#' @param this_plot_cex Numeric scalar; scaling for the plot itself. Default is \code{0.8}.
#' @param this_lab_cex Numeric scalar; scaling for plot labels. Default is the value of \code{this_plot_cex}.
#' @param this_axis_cex Numeric scalar; scaling for plot axis. Default is the value of \code{this_plot_cex}.
#' @param this_mar Numeric vector; set margins for the plot. Default is \code{c(4,4,4,0.5)}.
#' @param this_reset Logical scalar; if TRUE, the values of \code{par} are reset. Default is \code{TRUE}.
#' @return Generate year over year plot of user-specified series. If series not specified, print out error message and return NULL.
#' @examples
#' plot_year_over_year(AirPassengers, 
#'                     "Airline Passenger Series (1949 - 1960)", 
#'                     this_legend_inset = -0.175)
#' @import graphics
#' @import stats
#' @import utils
#' @export
plot_year_over_year <- function(this_series = NULL, main_title = NULL, 
                                main_title_line = 1.75, main_title_cex = NULL, this_col = NULL,
                                start_plot = NULL, this_legend = TRUE, this_legend_cex = 0.75,
                                this_right_mar = 5.25, this_legend_inset = -0.15, 
                                this_plot_cex = 0.8, this_lab_cex = NULL,
                                this_axis_cex = NULL, this_mar = c(4,4,4,0.5), this_reset = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 3.8, 5/12/2023

   if (is.null(this_series)) {
       stop("Argument this_series must be specified.")
   }

    # set cex values if not set by user
   if (is.null(this_lab_cex)) {
        this_lab_cex <- this_plot_cex
   }
   if (is.null(this_axis_cex)) {
        this_axis_cex <- this_plot_cex
   }
   if (is.null(main_title_cex)) {
        main_title_cex <- this_plot_cex + 0.1
   }

   # get time series information
   if (is.null(start_plot)) {
       this_start <- start(this_series)
   } else {
       this_start <- start_plot
   }
   this_freq <- frequency(this_series)
   this_end   <- end(this_series)

   # set first and last year of plot, number of years
   this_first_year <- this_start[1]
   this_last_year  <- this_end[1]
   if (this_end[2] == 1) {
       this_last_year <- this_last_year - 1
   }

   n_years <- this_last_year - this_first_year + 1

   # set colors used in plots
   if (is.null(this_col)) {
       this_col <- rainbow(n_years)
   } else {
       if (length(this_col) == 1) {
           this_col <- wheel_invisible(this_col, n_colors = n_years)
       } else {
           if (length(this_col) < n_years) {
               stop(paste0("Specify ", n_years, " colors in argument this_col."))
           }
       }
   }
   this_range <- range(this_series)

   # plot first segment
   this_segment <- window(this_series, start = this_start,
                          end = c(this_first_year+1, 1))
   this_x <- seq(this_start[2], this_freq+1)

   this_x_lab <- NULL
   this_axis_names <- NULL
   if (this_freq == 12) { 
       this_x_lab <- "Months"
       this_axis_names <- month.abb[c(1:12,1)]
   }
   if (this_freq == 4)  { 
       this_x_lab <- "Quarters" 
   }

   if (this_legend) {
       this_mar <- c(this_mar[1:3], this_right_mar)
       par(mar=this_mar, cex = this_plot_cex, cex.axis = this_axis_cex,
           cex.lab = this_lab_cex, xpd=TRUE)
       this_years <- seq(this_first_year, this_last_year)
   } else {
       par(mar = this_mar, cex = this_plot_cex, cex.axis = this_axis_cex,
           cex.lab = this_lab_cex)
   }

   plot(this_x, this_segment, ylim = this_range, xaxt = "n",
            col = this_col[1], xlim = c(1, this_freq+1), type = "l",
            ylab = " ", xlab = " ")
   if (!is.null(main_title)) {
       mtext(main_title, 3, main_title_line, cex = main_title_cex)
   }
   if (!is.null(this_x_lab)) {
       mtext(this_x_lab, 1, 2.5, cex = this_lab_cex)
   }

   # plot final segment
   this_segment <- window(this_series, start = c(this_last_year, 1),
                          end = this_end)

   this_x <- seq(1, this_end[2])
   lines(this_x, this_segment, col = this_col[n_years])

   # plot rest of years
   this_seq <- seq(this_first_year + 1, this_last_year - 1)
   this_x <- seq(1, this_freq+1)

   this_i <- 2
   for (y in this_seq) {
        this_segment <- window(this_series, start = c(y,1), end = c(y+1, 1))
        lines(this_x, this_segment, col = this_col[this_i])
        this_i <- this_i + 1
   }

   # construct x axis
   if (is.null(this_axis_names)) {
       axis(1, at = this_x, labels=this_x)
   } else {
       axis(1, at = this_x, labels=this_axis_names)
   }

   # construct legend, if specified
   if (this_legend) {
       legend("topright", inset = c(this_legend_inset, 0), legend = this_years, col = this_col,
              title = "Years", cex = this_legend_cex, lty = rep(1, n_years))
   }

   if (this_reset) { reset_par() }


}
