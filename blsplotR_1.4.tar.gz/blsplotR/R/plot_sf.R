#' Seasonal factor (and the SI-ratios) plot grouped by month/quarter
#'
#' Generates a special plot of the seasonal factors (and the SI-ratios) grouped by month/quarter
#'
#' @param this_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @param this_table Table from the X-13ARIMA-SEATS output (such as \code{e18} or \code{s18}) used in the plot; if NULL, the seasonal factor (either D11 for X-11 or S11 for SEATS) will be used.
#' @param add_si Logical scalar; indicates if seasonal factor plots will include SI ratios for X-11 seasonal adjustments. Default is not including SI ratios.
#' @param main_title Character string; main title of plot.  Default is  \code{'Seasonal Sub-Plots'}.
#' @param y_label Character string; y-axis label for plot, if specified.
#' @param y_limit Numeric vector of length 2; Range of values you wish the plot to be plotted over. Default is range of the seasonal factors.
#' @param this_xlab Character string; label for x-axis of plot.  Default is a blank x-axis.
#' @param this_col Character array of length 3; color used for seasonal factors, SI-ratios, and seasonal mean. Default is \code{c("darkgreen", "darkblue", "darkgrey")}.
#' @param add_mean_line Logical scalar; indicates if seasonal factor plots will include lines for seasonal means. Default includes lines for seasonal means.
#' @param add_legend Logical scalar; indicates if legend is produced for this plot. Default is legend not produced
#' @param this_legend_position Character string; indicates position of legend. Default is \code{'topleft'}.
#' @param this_legend_title Character string; indicates title of legend. Default is \code{'Series'}.
#' @param this_legend_inset Integer scalar; indicates inset for legend. Default is \code{0}.
#' @param this_legend_cex Numeric scalar; scaling for legend. Default is \code{0.8}.
#' @param this_plot_cex Numeric scalar; scaling for the plot itself. Default is \code{0.8}.
#' @param this_lab_cex Numeric scalar; scaling for plot labels. Default is the value of \code{this_plot_cex}.
#' @param this_main_cex Numeric scalar; scaling for main plot title. Default is the value of \code{this_plot_cex + 0.1}.
#' @param this_axis_cex Numeric scalar; scaling for plot axis. Default is the value of \code{this_plot_cex}.
#' @param this_mar Numeric vector; set margins for the plot. Default is \code{c(4.1, 2.1, 4.1, 0.5)}.
#' @param main_title_line Integer scalar; position of main title of plot.  Default is \code{2.25}.
#' @param this_reset Logical scalar; if TRUE, the values of \code{par} are reset. Default is \code{TRUE}.
#' @return Generates a special plot of the seasonal factors (and the SI-ratios) grouped by month/quarter
#' @examples
#' air_seas <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', x11='')
#' plot_sf(air_seas, add_si = TRUE, main_title = 'Air Passengers Seasonal Sub-Plots',
#'         this_col = c('darkgreen', 'darkblue', 'grey'), add_legend = TRUE)
#' @import graphics
#' @import stats
#' @export
plot_sf <- function(this_seas = NULL, this_table = NULL, add_si = FALSE, main_title = "Seasonal Sub-Plots",
    y_label = NULL, y_limit = NULL, this_xlab = " ", this_col = c("darkgreen", "darkblue", "darkgrey"), 
    add_mean_line = TRUE, add_legend = FALSE, this_legend_position = "topleft", this_legend_title = "SF Plot",
    this_legend_inset = 0, this_legend_cex = 0.8, this_plot_cex = 0.8, this_lab_cex = NULL, this_main_cex = NULL,
    this_axis_cex = NULL, this_mar = c(4.1, 2.1, 4.1, 0.5), main_title_line = 2.25, this_reset = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 4.1, 5/1/2023

    # check if a value is specified for \code{this_seas}
    if (is.null(this_seas)) {
        stop("must specify a seas object")
    }

    # set cex values if not set by user
    if (is.null(this_lab_cex)) {
        this_lab_cex <- this_plot_cex
    }
    if (is.null(this_axis_cex)) {
        this_axis_cex <- this_plot_cex
    }
    if (is.null(this_main_cex)) {
        this_main_cex <- this_plot_cex + 0.1
    }
    par(mar = this_mar, cex = this_plot_cex, cex.axis = this_axis_cex, cex.lab = this_lab_cex)

    if (is.null(this_table)) {
        # Try to extract X-11 seasonal factors.
        sf <- tryCatch(seasonal::series(this_seas, "d10"), error = function(e) {
            NULL
        })
        # If X-11 seasonal factors not available, try to extract SEATS seasonal factors.
        if (is.null(sf)) {
            sf <- tryCatch(seasonal::series(this_seas, "s10"), error = function(e) {
                NULL
            })
            # If SEATS seasonal factors not available, print error message and stop
            if (is.null(sf)) {
                stop("unable to extract seasonal factors")
            }
            # If SEATS adjustment done, set add_si to FALSE
            if (add_si) {
                add_si <- FALSE
            }
        }
    } else {
        # Try to extract factors.
        sf <- tryCatch(seasonal::series(this_seas, this_table), error = function(e) {
            NULL
        })
        # If SEATS seasonal factors not available, print error message and stop
        if (is.null(sf)) {
            stop(paste0("unable to extract table ", this_table))
        }
        if (add_si) {
            add_si <- FALSE
        }
    }
    # If add_si is TRUE, extract si ratios
    if (add_si) {
        si <- tryCatch(seasonal::series(this_seas, "d8"), error = function(e) {
            NULL
        })
        # If X-11 SI ratios not available, print error message and stop
        if (is.null(si)) {
            stop("unable to extract SI ratios")
        }
    }

    # Extract cycle and frequency
    sf_period <- cycle(sf)
    freq <- frequency(sf)

    # Set up range of x and y axis.
    if (is.null(y_limit)){
        y_limit <- range(sf)
        if (add_si) {
            y_limit <- range(y_limit, si)
        }
    }
    x_limit <- seq(0, freq + 1)

    # Get transformation, then set value of factor mean.
    this_trans <- seasonal::udg(this_seas, "transform")
    if (this_trans == "Automatic selection") {
        this_trans <- seasonal::udg(this_seas, "aictrans")
    }
    if (this_trans == "Log(y)") {
        h_bar <- 1
    } else {
        h_bar <- 0
    }
    
    if (is.null(y_label)) {
        y_label <- " "
    }

    # create the plotting frame, with custom x-axis and create reference line for factor mean.
    plot(x_limit, seq(y_limit[1], y_limit[2], length.out = length(x_limit)), type = "n",
        ylim = y_limit, xlab = this_xlab, ylab = y_label, xaxt = "n")
        
    if (!is.null(main_title)) {
        mtext(main_title, 3, main_title_line, cex = this_main_cex)
    }

    # Generate monthly labels
    if (freq == 12) {
        this_label <-
           c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    } else {
        # Generate quarterly labels
        if (freq == 4) {
            this_label <- paste0("q", 1:4)
        } else {
            this_label <- paste0("p", 1:freq)
        }
    }
    axis(1, at = 1:freq, labels = this_label)
    if (add_mean_line) {
        abline(h = h_bar, col = this_col[3], lty = 2)
    }

    # create vector for factor mean.
    this_mu <- array(h_bar, freq)

    # loop through each month or quarter.
    for (i in 1:freq) {

        # produce limits for period plot.
        s1 <- (i - 1) + 0.6
        s2 <- i + 0.4

        # save seasonal factors for period i, and generate number of factors.
        this_sf <- sf[sf_period == i]
        number_sf <- length(this_sf)

        # Generate X values for period i, mean of SF for period i
        this_period_x <- seq(s1, s2, length.out = number_sf)
        this_mu[i] <- mean(this_sf)

        # Generate line for mean of SF for period i
        segments(s1, this_mu[i], s2, this_mu[i], col = this_col[3])

        if (add_si) {
            # Generate SI ratios for period i
            this_si <- si[sf_period == i]
            # Plot SI ratios for period i
            lines(this_period_x, this_si, col = this_col[2])
            # Plot SF in high density plot for period i
            for (j in 1:number_sf) {
                segments(this_period_x[j], this_mu[i], this_period_x[j], this_sf[j], col = this_col[1])
            }
        } else {
            # Plot SF for period i
            lines(this_period_x, this_sf, col = this_col[1])
        }

    }
    # Join seasonal subplots with grey line
    lines(1:freq, this_mu, col = this_col[3], lty = 3)

    # add legend to plot
    if (add_legend) {
        if (add_si) {
            legend(this_legend_position, c("SF", "SI", "SF Mean"), title = this_legend_title, inset = this_legend_inset,
                 cex = this_legend_cex, col = this_col, lty = rep(1,3))
        } else {
            if (is.null(this_table)) {
                legend(this_legend_position, c("SF", "SF Mean"), title = this_legend_title, inset = this_legend_inset,
                    cex = this_legend_cex, col = c(this_col[1], this_col[3]), lty = rep(1,2))
            } else {
                this_legend_title <- paste0(this_table, " Plot")
                legend(this_legend_position, c(this_table, paste0(this_table, " Mean")),
                    title = this_legend_title, inset = this_legend_inset,
                    cex = this_legend_cex, col = c(this_col[1], this_col[3]), lty = rep(1,2))
            }
        }
    }


}
