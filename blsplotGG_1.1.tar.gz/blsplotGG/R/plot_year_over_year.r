#' Plot year over year plot 
#'
#' Generate year over year plot of a user-specified ts object.
#'
#' @param this_series Numeric matrix; columns of time series object to be plotted.
#' @param main_title Character string; main title of plot. 
#'        The default title is the name of the series passed to this function.
#' @param sub_title Character string; subtitle of plot. There is no default subtitile.
#' @param this_y_label Character string; y-axis label for plot, if specified.
#' @param y_limit Numeric vector of length 2; Range of values you wish the plot to be plotted over. 
#'                Default is range of the series specified.
#' @param this_x_label Label for X axis. Default is \code{"Month"} or \code{"Quarter"}.
#' @param start_plot Integer vector of length 2; Starting date for plot. Default is starting date for the time series.
#' @param do_grid Logical scalar; indicates if plots will have grid lines. Default is no grid lines.
#' @param line_color Character scalar; color used for plot. User should specify one color for each column of the matrix specified.
#'        Default is the \code{RColorBrewer} pallatte \code{"Paired"}.
#' @param this_palette Character string; default \code{RColorBrewer} palette.
#'        Deault is \code{"Paired"}.
#' @return Generate plot of user-specified series. If matrix not specified, print out error message and return NULL.
#' @examples
#' this_yyplot <- 
#'     plot_year_over_year(AirPassengers, this_y_label = "Air", this_palette = "Dark2")
#' @importFrom rlang .data
#' @export
plot_year_over_year <- 
    function(this_series = NULL, main_title = NULL, sub_title = NULL, this_y_label = NULL, 
	         y_limit = NULL, this_x_label = NULL, start_plot = NULL, do_grid = FALSE, 
			 line_color = NULL, this_palette = "Paired") {
    # Author: Brian C. Monsell (OEUS) Version 1.5, 3/6/2024

    if (is.null(this_series)) {
        stop("Argument this_series must be specified.")
    }
	
	if (is.null(main_title)) {
	    main_title <- paste0("Year-Over-Year Plot of ", deparse(substitute(this_series)))
	}

	this_period <- cycle(this_series)
	this_year  <- time(this_series) %/% 1
	
	if (is.null(this_x_label)) {
		if (max(this_period) == 12) {
			this_x_label <- "Month"
		} else {
			if (max(this_period) == 4) {
				this_x_label <- "Quarter"
			} else {
				this_x_label <- "Period"
			}
		}
	} 
	
	num_years <- length(unique(this_year))
	
	if (is.null(line_color)) {
	    this_palette_max <- RColorBrewer::brewer.pal.info[this_palette, "maxcolors"]
	    if (num_years < 3) {
			line_color <- RColorBrewer::brewer.pal(3, this_palette)[1:num_years]
		} else {
			if (num_years <= this_palette_max) {
				line_color <- RColorBrewer::brewer.pal(num_years, this_palette)
			} else {
				this_color <- RColorBrewer::brewer.pal(this_palette_max, this_palette)
				line_color <- grDevices::colorRampPalette(this_color)(num_years)
			}
		}
	} else {
		if (length(line_color) < num_years) {
			warning("Number of line colors specified less than number of years.")
			warning("Will use colorRampPalette to increase number of colors.")
			line_color <- grDevices::colorRampPalette(line_color)(num_years)
		}
	}
	

    # If start_plot specified, shorten series
    if (!is.null(start_plot)) {
        this_series <- window(this_series, start = start_plot)
    }
    
	if (is.null(y_limit)) {
		y_limit <- range(this_series)
	}
 
	this_data <-
		data.frame(value = as.double(this_series), 
		           period = as.double(this_period), 
				   year = as.factor(as.double(this_year)))

	this_plot <- ggplot2::ggplot(data = this_data, 
                          ggplot2::aes(x = as.factor(.data$period), 
                                       y = .data$value, 
                                       group = .data$year, 
                                       colour = .data$year)) + 
		ggplot2::geom_line() +
		ggplot2::geom_point() +
		ggplot2::scale_x_discrete(name = this_x_label, 
                                  breaks = 1:12, 
                                  labels = month.abb) +
		ggplot2::scale_colour_manual(values = line_color) +
		ggplot2::labs(title = main_title, 
		              subtitle = sub_title, 
					  y = this_y_label)

    # add grid.
    if (do_grid) {
	    this_plot <- this_plot + 
		    ggplot2::theme(panel.grid.major = ggplot2::element_blank(), 
			               panel.grid.minor = ggplot2::element_blank())
    }

	return(this_plot)
	
}