#' Import movereg results
#'
#' Import results from the movereg signal extraction program.
#'
#' @param this_base character string; base file name from MoveReg run. 
#' @return A list of Numeric vectors read from MoveReg output and converted into tis time series objects: wk, year, sa, safactor, obs,outlier, and holiday
#' @examples
#' \dontrun{ic_movereg_nolog_tc_xts <- get_movereg("ic.nolog.tc")}
#' @import stats
#' @export
get_movereg <- function(this_base = NULL) {
    # Author: Brian C. Monsell (OEUS), Version 1.7, February 3, 2022

   if (is.null(this_base)) {
       stop("must specify the base output file name from a MoveReg run.")
   }
   
   this_file <- paste0(this_base,".results2.out")
   if (!file.exists(this_file)) {
       stop(paste0("The file ", this_file, " does not exist. Check the file path."))
   }

   this_df <- as.data.frame(matrix(scan(this_file, skip = 8), ncol = 7, byrow = TRUE))
   colnames(this_df) <- c("wk", "year", "sa", "safactor", "obs", "outlier", "holiday")
   
   this_list <- list()
   this_filter <- this_df$obs > 0
   
   this_list$start <- c(this_df$year[1], this_df$wk[1])

   this_list$sa       <- 
        tis::tis(this_df$sa[this_filter], start = this_list$start, tif = "wsaturday")
   this_list$safactor <- 
        tis::tis(this_df$safactor, start = this_list$start, tif = "wsaturday")
   this_list$obs      <- 
        tis::tis(this_df$obs[this_filter], start = this_list$start, tif = "wsaturday")
   this_list$outlier  <- 
        tis::tis(this_df$outlier, start = this_list$start, tif = "wsaturday")
   this_list$holiday  <- 
        tis::tis(this_df$holiday, start = this_list$start, tif = "wsaturday")

   this_list$year     <- 
        tis::tis(this_df$year, start = this_list$start, tif = "wsaturday")
   this_list$week     <- 
        tis::tis(this_df$wk, start = this_list$start, tif = "wsaturday")
              
   return(this_list)

}