#' Import movereg results
#'
#' Import results from the movereg signal extraction program, converted into an xts time series object
#'
#' @param this_base character string; base file name from MoveReg run. 
#' @return A list of Numeric vectors read from MoveReg output, converted into an xts time series matrix object with the following columns: wk, year, sa, safactor, obs,outlier, and holiday
#' @examples
#' \dontrun{ic_movereg_nolog_tc_xts <- get_movereg_xts("ic.nolog.tc")}
#' @import stats
#' @export
get_movereg_xts <- function(this_base = NULL) {
    # Author: Brian C. Monsell (OEUS), Version 1.4, February 3, 2022

   if (is.null(this_base)) {
       stop("must specify the base output file name from a MoveReg run.")
   }

   this_file <- paste0(this_base,".results2.out")
   if (!file.exists(this_file)) {
       stop(paste0("The file '", this_file, "' does not exist. Check the file path."))
   }

   this_df           <- as.data.frame(matrix(scan(this_file, skip = 8), ncol = 7, byrow = TRUE))
   colnames(this_df) <- c("wk", "year", "sa", "safactor", "obs", "outlier", "holiday")
   
   jan_first  <- as.Date(paste0(this_df$year[1], "-01-01"))
   first_date <- jan_first + (this_df$wk[1] * 7) - lubridate::wday(jan_first)
   this_index <- first_date + (0:(length(this_df$wk)-1)) * 7
   
   this_end_date <- get_movereg_end_date(this_base)
   this_filter   <- this_index > this_end_date + 1

   this_df$sa[this_filter]   <- NA
   this_df$obs[this_filter]  <- NA
   
   this_matrix <- cbind(this_df$wk, this_df$year, this_df$sa, this_df$safactor, 
                        this_df$obs, this_df$outlier, this_df$holiday)
   colnames(this_matrix) <- c("week", "year", "sa", "safactor", "obs", "outlier", "holiday")
              
   this_xts <- xts::xts(this_matrix, order.by = this_index)

   return(this_xts)

}