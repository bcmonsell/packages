#' Import movereg results
#'
#' Import results from the movereg signal extraction program.
#'
#' @param this_base character string; base file name from MoveReg run. 
#' @return A list of Numeric vectors read from MoveReg output: wk, year, sa, safactor, obs, outlier, and holiday
#' @examples
#' \dontrun{this_end_date <- get_movereg_end_date("ic.nolog.tc")}
#' @import stats
#' @export
get_movereg_end_date <- function(this_base) {
   # Author: Brian C. Monsell (OEUS), Version 1.4, February 3, 2022
   this_file <- paste0(this_base, ".global.out")
   if (!file.exists(this_file)) {
       stop(paste0("The file '", this_file, "' does not exist. Check the file path."))
   }
   temp <- readLines(this_file, 5)
   
   last_year <- as.integer(substr(temp[5],16,19))
   last_week <- as.integer(substr(temp[5],27,28))
   
   jan_first <- as.Date(paste0(last_year[1], "-01-01"))
   last_date <- jan_first + (last_week * 7) - lubridate::wday(jan_first)

   return(last_date)
}
